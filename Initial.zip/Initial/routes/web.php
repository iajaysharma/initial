<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    //return view('welcome');
    return redirect('admin');
});

//Auth::routes();

//Route::get('/home', 'HomeController@index')->name('home');
Route::get("/pages/{slug}",'Admin\PageController@view')->name('pages.view');
Route::get('/verification/{token}','HomeController@verification')->name('users.verification');
Route::get('/reset/{token}','HomeController@reset')->name('users.reset');
Route::post('/reset/{token}','HomeController@reset')->name('users.reset');
Route::group(['namespace'=>'Admin','prefix'=>'admin'],function(){
	Route::get('/','Auth\LoginController@showLoginForm')->name('admin.login');
	Route::post('/','Auth\LoginController@login');
	Route::post('/admin','Auth\LoginController@login');
	Route::get('/dashboard','AdminController@dashboard')->name('admin.dashboard');
	Route::get('/logout','AdminController@logout')->name('admin.logout');
	Route::any('/profile','AdminController@profile')->name('admin.profile');
	Route::any('/reset-password','AdminController@reset_password')->name('admin.reset_password');
	Route::get('/change-password/{token}','AdminController@change_password')->name('admin.change_password');
	Route::post('/change-password/{token}','AdminController@change_password');
	Route::post('/update-password','AdminController@update_password')->name('admin.update_password');

	// Users Routes
	Route::get('/users','UserController@index')->name('users.index');
	Route::post('/users/datatables','UserController@datatables')->name('users.datatables');
	Route::get('/users/view/{id}','UserController@view')->name('users.view');
	Route::post('/users/delete','UserController@delete')->name('users.delete');
	Route::post('/users/status','UserController@status')->name('users.status');
	Route::any('/users/add/{id?}','UserController@add')->name('users.add');
	Route::post('/users/bulk_delete','UserController@bulk_delete')->name('users.bulk_delete');

	// Email Template Routes

	Route::get('/templates','TemplateController@index')->name('templates.index');
	Route::post('/templates/datatables','TemplateController@datatables')->name('templates.datatables'); 
	Route::post('/templates/delete','TemplateController@delete')->name('templates.delete');
	Route::any('/templates/add/{id?}','TemplateController@add')->name('templates.add');


	// CMS Pages Routes

	Route::get('/pages','PageController@index')->name('pages.index');
	Route::post('/pages/datatables','PageController@datatables')->name('pages.datatables');  
	Route::post('/pages/delete','PageController@delete')->name('pages.delete');
	Route::post('/pages/bulk_delete','PageController@bulk_delete')->name('pages.bulk_delete');
	Route::any('/pages/add/{id?}','PageController@add')->name('pages.add');

	// Site Settings Routes

	Route::get('/settings','SettingController@index')->name('settings.index');
	Route::post('/settings/datatables','SettingController@datatables')->name('settings.datatables'); 
	Route::post('/settings/delete','SettingController@delete')->name('settings.delete');
	Route::any('/settings/add/{id?}','SettingController@add')->name('settings.add');

	// Categories Route
	Route::get('/category','CategoryController@index')->name('category.index');
	Route::post('/category/datatables','CategoryController@datatables')->name('category.datatables');
	Route::post('/category/delete','CategoryController@delete')->name('category.delete');
	Route::post('/category/status','CategoryController@status')->name('category.status');
	Route::any('/category/add/{id?}','CategoryController@add')->name('category.add');

});
