<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });

Route::group(['namespace' => 'Api'],function($request){
    
    Route::any('authorize-token', 'AuthenticateController@authorizeToken');
    Route::post('signup', 'UserController@signup');
    Route::post('signin', 'UserController@signin');
    Route::post('otp', 'UserController@otp');
    Route::post('forgot', 'UserController@forgot');
    Route::post('check-user', 'UserController@checkUser');
    Route::get('get-country', 'UserController@getCountry');
    Route::group(['middleware' => 'jwt.auth'], function () {
        Route::post('getProfile', 'UserController@getProfile'); 
        Route::post('logout', 'UserController@logout'); 
        Route::post('updateProfile', 'UserController@updateProfile');
        Route::post('change-password', 'UserController@changePassword');

    });
    
});
