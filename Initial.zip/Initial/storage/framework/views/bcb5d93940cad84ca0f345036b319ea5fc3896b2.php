<?php $__env->startSection('content'); ?>
<div class="form-signin ">
   <div class="ui center aligned segment">
  Verification
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default-auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>