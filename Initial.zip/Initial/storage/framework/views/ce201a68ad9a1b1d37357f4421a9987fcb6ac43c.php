<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-4">
		<a href="<?php echo e(route('users.index')); ?>">
			<div class="ui steps" style="width: 100%;">
				<div class="step">
					<i class="circular users icon"></i>
					<div class="content">
						<div class="title">Users (<?php echo e($users); ?>)</div>
					</div>
				</div>
			</div>
		</a>
	</div>

	<div class="col-md-4">
		<a href="<?php echo e(route('pages.index')); ?>">
			<div class="ui steps" style="width: 100%;">
				<div class="step">
					<i class="circular file icon"></i>
					<div class="content">
						<div class="title">CMS Pages (<?php echo e($pages); ?>)</div>
					</div>
				</div>
			</div>
		</a>
	</div>

	<div class="col-md-4">
		<a href="<?php echo e(route('templates.index')); ?>">
			<div class="ui steps" style="width: 100%;">
				<div class="step">
					<i class="circular envelope icon"></i>
					<div class="content">
						<div class="title">Email Templates (<?php echo e($templates); ?>)</div>
					</div>
				</div>
			</div>
		</a>
	</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>