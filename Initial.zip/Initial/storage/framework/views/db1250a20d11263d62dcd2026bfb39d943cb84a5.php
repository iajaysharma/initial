<?php $__env->startSection('content'); ?>
<!-- Start Page Content -->
<div class="row">
	<div class="col-lg-12">
		<div class="ui raised segment">
			<div class="avatar text-center">
				<?php if($data->profile_picture && file_exists($data->profile_picture)): ?>
				<img alt="<?php echo e($data->name); ?>" style="margin:0 auto;max-height: 75px;" src="<?php echo e(url($data->profile_picture)); ?>">
				<?php else: ?>
				<img class="media-object img-thumbnail user-img" style="margin:0 auto;" alt="User Picture" src="<?php echo e(url('public/admin/assets/img/user.gif')); ?>"> 
				<?php endif; ?>
			</div>
			<h3 class="text-center" style="margin-top: 5px;"><?php echo e($data->name); ?></h3><hr>
			<div style="text-align:center">
				<div class="row">
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Name</strong>
						<br>
						<p class="text-muted"><?php echo e($data->name); ?></p>
					</div>
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Email</strong>
						<br>
						<p class="text-muted"><?php echo e($data->email); ?></p>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Country</strong>
						<br>
						<p class="text-muted"><?php echo e(isset($data->country->name)?$data->country->name:'---'); ?></p>
					</div>
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Mobile</strong>
						<br>
						<p class="text-muted"><?php echo e(($data->mobile)?$data->mobile:'---'); ?></p>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Gender</strong>
						<br>
						<p class="text-muted"><?php echo e(($data->gender)?$data->gender:'---'); ?></p>
					</div>
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Date of Birth</strong>
						<br>
						<p class="text-muted"><?php echo e(($data->dob)?date("d M Y",strtotime($data->dob)):'---'); ?></p>
					</div>
				</div> 
				<div class="row">
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Username</strong>
						<br>
						<p class="text-muted"><?php echo e(($data->username)?$data->username:'---'); ?></p>
					</div>
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Address</strong>
						<br>
						<p class="text-muted"><?php echo e(($data->address)?$data->address:'---'); ?></p>
					</div>
				</div> 
				<div class="row">
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Status</strong>
						<br>
						<?php if($data->status==1): ?>
						<span class="btn btn-success btn-sm">Active</span>
						<?php elseif($data->status==0): ?>
						<span class="btn btn-danger btn-sm">InActive</span>
						<?php elseif($data->status==2): ?>
						<span class="btn btn-danger btn-sm">UnVerified</span>
						<?php else: ?>
						<span class="btn btn-success btn-sm">N/A</span>
						<?php endif; ?>
					</div>
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Created At</strong>
						<br>
						<p class="text-muted"><?php echo e(($data->created_at)?date("d M Y",strtotime($data->created_at)):'---'); ?></p>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<a class="btn btn-success" href="javascript:history.back()">Go Back</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- End PAge Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>