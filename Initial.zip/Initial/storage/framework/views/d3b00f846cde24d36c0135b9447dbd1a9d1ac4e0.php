<?php $__env->startSection('content'); ?>
 <!-- Container fluid  -->
<div class="container-fluid">
    <!-- Start Page Content -->
    <div class="row">
        <div class="col-12">
            <div class="ui segment">
                <div class="body">
                    <h4 class="title"><?php echo e($title); ?></h4>
                    <div class="table-responsive m-t-40">
                        <table id="users_datatables" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Email</th> 
                                    <th>Created</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End PAge Content -->
</div>
<!-- End Container fluid  -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    function confirm_delete(id){      
        if(id!=""){
            swal({
              title: 'Are you sure?',
              text: "You won't be able to revert this!", 
              buttons: true,
            }).then((result) => {
              if (result) {
                    $(".segment").addClass("loading");
                    $.ajax({
                        url: '<?php echo e(route('users.delete')); ?>',
                        type: 'POST',
                        data:{user_id:id},
                        headers: {
                        'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function (response) {
                          var data = JSON.parse(response)
                          if(data.type=='success'){
                                $("#delete_"+id).parents("tr").remove();
                          }else{
                            swal(data.data);
                          }
                          $(".segment").removeClass("loading");
                        },error:function(error){
                          var data = JSON.parse(error)
                          swal(data.data);
                          $(".segment").removeClass("loading");
                        }
                    });
              }
            })
        }
    }
	function changeStatus(id)
	{ 
      $(".segment").addClass("loading");
	    $.ajax({
	        url: '<?php echo e(route('users.status')); ?>',
	        type: 'POST',
	        data:{user_id:id},
	        headers: {
	        'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
	        },
	        success: function (response) {
	          $("#status_"+id).html(response);
            $(".segment").removeClass("loading");
	        },error:function(error){
            $(".segment").removeClass("loading");
          }
	    });
	}
	$(function() {
    var table = $('#users_datatables').DataTable({
    processing: true,
    serverSide: true,
    order: [[0, "desc" ]],
    "ajax":{
    "url": '<?php echo route('users.datatables'); ?>',
    "dataType": "json",
    "type": "POST",
    "data":{ _token: "<?php echo e(csrf_token()); ?>"}
    },
    columns: [ 
      { data: 'id', name: 'id', orderable:true },
      { data: 'name', name: 'name', orderable:true  },
      { data: 'email', name: 'email', orderable:true}, 
      { data: 'created_at', name: 'created_at', orderable:true },
      { data: 'status', name: 'status', orderable:true},
      { data: 'action', name: 'action', orderable:false }  
    ],
    "columnDefs": [
    { "searchable": false, "targets": 0 }
    ]
    ,language: {
        searchPlaceholder: "Search by id,name or email"
    }
    });    
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>