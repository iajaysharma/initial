<?php
$currentAction = \Route::currentRouteAction();
list($controller, $action) = explode('@', $currentAction);
$controller = preg_replace('/.*\\\/', '', $controller);
?>
<div id="left">
    
    <!-- #menu -->
    <ul id="menu" class="bg-blue dker"> 
        <li class="nav-divider"></li>
        <?php $active = ($controller=="AdminController" && $action=="dashboard" )?"active":""; ?>
        <li class="<?php echo e($active); ?>">            
            <a href="<?php echo e(route('admin.dashboard')); ?>">
                <i class="fa fa-dashboard"></i><span class="link-title">&nbsp;Dashboard</span>
            </a>
        </li>
        <?php 
            $active = ($controller=="UserController" && in_array($action,['index','view']) )?"active":"";
        ?> 
        <li class="<?php echo e($active); ?>">
            <a href="javascript:;"><i class="fa fa-users"></i>
                <span class="link-title">Users</span>
                <span class="fa arrow"></span>
            </a>
            <ul aria-expanded="false" class="collapse">  
                <?php $active = ($controller=="UserController" && $action=="index" )?"active-link":""; ?> 
                <li class="<?php echo e($active); ?>"><a class="<?php echo e($active); ?>" href="<?php echo e(route('users.index')); ?>"><i class="fa fa-angle-right"></i>&nbsp; View All </a></li>
            </ul>
        </li>
        <?php 
            $active = ($controller=="TemplateController" && in_array($action,['index','view','add']) )?"active":"";
        ?> 
        <li class="<?php echo e($active); ?>">
            <a href="javascript:;"><i class="fa fa-envelope"></i>
                <span class="link-title">Email Template</span>
                <span class="fa arrow"></span>
            </a>
            <ul aria-expanded="false" class="collapse">  
                <?php $active = ($controller=="TemplateController" && $action=="index" )?"active-link":""; ?> 
                <li class="<?php echo e($active); ?>"><a class="<?php echo e($active); ?>" href="<?php echo e(route('templates.index')); ?>"><i class="fa fa-angle-right"></i>&nbsp; View All </a></li>
                <?php $active = ($controller=="TemplateController" && $action=="add" )?"active-link":""; ?> 
                <li class="<?php echo e($active); ?>"><a class="<?php echo e($active); ?>" href="<?php echo e(route('templates.add')); ?>"><i class="fa fa-angle-right"></i>&nbsp; Add New </a></li>
            </ul>
        </li>
        <?php 
            $active = ($controller=="PageController" && in_array($action,['index','add']) )?"active":"";
        ?> 
        <li class="<?php echo e($active); ?>">
            <a href="javascript:;"><i class="fa fa-file-text"></i>
                <span class="link-title">CMS Pages</span>
                <span class="fa arrow"></span>
            </a>
            <ul aria-expanded="false" class="collapse">  
                <?php $active = ($controller=="PageController" && $action=="index" )?"active-link":""; ?> 
                <li class="<?php echo e($active); ?>"><a class="<?php echo e($active); ?>" href="<?php echo e(route('pages.index')); ?>"><i class="fa fa-angle-right"></i>&nbsp; View All </a></li>
                <?php $active = ($controller=="PageController" && $action=="add" )?"active-link":""; ?> 
                <li class="<?php echo e($active); ?>"><a class="<?php echo e($active); ?>" href="<?php echo e(route('pages.add')); ?>"><i class="fa fa-angle-right"></i>&nbsp; Add New </a></li>
            </ul>
        </li>
        <?php 
            $active = ($controller=="SettingController" && in_array($action,['index','add']) )?"active":"";
        ?> 
        <li class="<?php echo e($active); ?>">
            <a href="javascript:;"><i class="fa fa-cog"></i>
                <span class="link-title">Site Settings</span>
                <span class="fa arrow"></span>
            </a>
            <ul aria-expanded="false" class="collapse">  
                <?php $active = ($controller=="SettingController" && $action=="index" )?"active-link":""; ?> 
                <li class="<?php echo e($active); ?>"><a class="<?php echo e($active); ?>" href="<?php echo e(route('settings.index')); ?>"><i class="fa fa-angle-right"></i>&nbsp; View All </a></li>
                <?php $active = ($controller=="SettingController" && $action=="add" )?"active-link":""; ?> 
                <li class="<?php echo e($active); ?>"><a class="<?php echo e($active); ?>" href="<?php echo e(route('settings.add')); ?>"><i class="fa fa-angle-right"></i>&nbsp; Add New </a></li>
            </ul>
        </li>
        </ul>
        <!-- /#menu -->
    </div>
    <!-- /#left -->