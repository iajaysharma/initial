<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo e($data->meta_content); ?>">
    <meta name="title" content="<?php echo e($data->meta_title); ?>">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
        <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e($data->title); ?> - <?php echo e(isset($site_settings['site_title'])?$site_settings['site_title']:''); ?></title>
    <!-- Bootstrap Core CSS -->
   <!-- Bootstrap -->
    <link rel="stylesheet" href="<?php echo e(url('public/admin/assets/lib/bootstrap/css/bootstrap.css')); ?>">
    
    <!-- Font Awesome --> 
    
    <!-- Metis core stylesheet -->  
    <style>
        img{
            max-height: 100%;
            max-width: 100%;
        }
    </style>
</head>
<body class="" style="background-color: rgba(221,221,221,0.509804);"> 
    <!-- Main wrapper  -->
    <div id="main-wrapper" style="padding: 40px 0px;">
        <div class="container" style="background-color: #fff;padding:20px;">            
            <?php echo $data->content; ?>

        </div>
    </div>
    <!-- End Wrapper -->
    <!-- All Jquery -->
    <script src="<?php echo e(url('public/admin/assets/lib/jquery/jquery.js')); ?>"></script> 
    <!--Bootstrap -->
    <script src="<?php echo e(url('public/admin/assets/lib/bootstrap/js/bootstrap.js')); ?>"></script>

</body>

</html>