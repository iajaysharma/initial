<div class="flash-message">
<?php if(session()->has('success') or session()->has('warning') or session()->has('info') or session()->has('danger')): ?>
<div class="flash-message" onClick= "this.remove();">
    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(session()->has($msg)): ?>
                <p class="alert absolte_alert  alert-<?php echo e($msg); ?>"><?php echo e(session()->get($msg)); ?> <a href="javascript:void(0)" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>

        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div> <!-- end .flash-message -->
<?php endif; ?>

</div>