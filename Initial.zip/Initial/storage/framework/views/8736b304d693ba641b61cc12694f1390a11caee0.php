<!doctype html>
<html>

<head>
    <meta charset="UTF-8">
    <!--IE Compatibility modes-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--Mobile first-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Admin <?php echo e((isset($title))?$title:''); ?></title>
    
    <meta name="description" content="">
    <meta name="author" content="">
    
    <meta name="msapplication-TileColor" content="#5bc0de" />
    <meta name="msapplication-TileImage" content="<?php echo e(url('public/admin/assets/img/metis-tile.png')); ?>" />
    
    <!-- Bootstrap -->
    <link rel="stylesheet" href="<?php echo e(url('public/admin/assets/lib/bootstrap/css/bootstrap.css')); ?>">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('public/admin/assets/font-awesome/css/font-awesome.min.css')); ?>">
    
    <!-- Metis core stylesheet -->
    <link rel="stylesheet" href="<?php echo e(url('public/admin/assets/css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/admin/assets/css/theme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/admin/css/helper.css')); ?>">
    
    <!-- metisMenu stylesheet -->
    <link rel="stylesheet" href="<?php echo e(url('public/admin/assets/lib/metismenu/metisMenu.css')); ?>">
    
    <!-- onoffcanvas stylesheet -->
    <link rel="stylesheet" href="<?php echo e(url('public/admin/assets/lib/onoffcanvas/onoffcanvas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/admin/css/semantic.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/admin/assets/UI-Icon-master/icon.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/admin/assets/lib/summernote/summernote.css')); ?>">    
    <!-- animate.css stylesheet -->
    <link rel="stylesheet" href="<?php echo e(url('public/admin/css/custom.css')); ?>">



<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
    <?php echo $__env->yieldContent('styles'); ?> 
    
  </head>

        <body class="  ">
            <div class="bg-dark dk" id="wrap">                
                <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('admin.layouts.sidebar_left', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div id="content">
                    <div class="outer">
                        <div class="inner bg-light lter"> 
                            <?php echo $__env->make('admin.layouts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <?php echo $__env->yieldContent('content'); ?> 
                        </div>
                        <!-- /.inner -->
                    </div>
                    <!-- /.outer -->
                </div>
                <!-- /#content -->                   
            </div>
            <!-- /#wrap -->
            <?php echo $__env->make('admin.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /#footer --> 
            <!--jQuery -->
            <script src="<?php echo e(url('public/admin/assets/lib/jquery/jquery.js')); ?>"></script> 
            <!--Bootstrap -->
            <script src="<?php echo e(url('public/admin/assets/lib/bootstrap/js/bootstrap.js')); ?>"></script>
            <!-- MetisMenu -->
            <script src="<?php echo e(url('public/admin/assets/lib/metismenu/metisMenu.js')); ?>"></script>
            <!-- onoffcanvas -->
            <script src="<?php echo e(url('public/admin/assets/lib/onoffcanvas/onoffcanvas.js')); ?>"></script>
            <!-- Screenfull -->
            <script src="<?php echo e(url('public/admin/assets/lib/screenfull/screenfull.js')); ?>"></script>


            <!-- Metis core scripts -->
            <script src="<?php echo e(url('public/admin/assets/js/core.js')); ?>"></script>
            <!-- Metis demo scripts -->
            <script src="<?php echo e(url('public/admin/assets/js/app.js')); ?>"></script>
            <script src="<?php echo e(url('public/admin/assets/lib/summernote/summernote.min.js')); ?>"></script>
            
            <script src="<?php echo e(url('public/admin/js/sweetalert.min.js')); ?>"></script>            
            <script src="<?php echo e(url('public/admin/assets/lib/datatables/jquery.dataTables.min.js')); ?>"></script>
            <script src="<?php echo e(url('public/admin/assets/lib/datatables/dataTables.bootstrap.min.js')); ?>"></script>
            <script src="<?php echo e(url('public/admin/assets/lib/datatables/jquery.tablesorter.min.js')); ?>"></script>
            <script src="<?php echo e(url('public/admin/assets/lib/datatables/jquery.ui.touch-punch.min.js')); ?>"></script>            
            <script src="<?php echo e(url('public/admin/js/custum.js')); ?>"></script>
            <?php echo $__env->yieldContent('scripts'); ?>
        </body>

</html>
