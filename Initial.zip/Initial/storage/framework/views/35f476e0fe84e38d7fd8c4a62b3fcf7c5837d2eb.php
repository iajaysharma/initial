<?php $__env->startSection('content'); ?>
<?php echo e(Form::model($data,array('url'=>'','files'=>'true','class'=>'ui form','id'=>'template-form','autocomplete'=>'off'))); ?>

<div class="ui segment">
  <div class="field">
    <label>Title</label>
    <?php echo e(Form::text('title',null,array('placeholder'=>'Title','id'=>'title'))); ?>

    <span class="error title"></span>
  </div>
  <div class="field">
    <label>Slug</label>
    <?php echo e(Form::text('slug',null,array('placeholder'=>'Title','id'=>'slug','readonly'=>'readonly'))); ?>

    <span class="error slug"></span>
  </div>
  <div class="field">
    <label>Content</label>
    <?php echo e(Form::textarea('content',null,array('placeholder'=>'Content','id'=>'content','class'=>'summernote'))); ?>

    <span class="error content"></span>
  </div>
  <div class="field">
    <label>Meta Title</label>
    <?php echo e(Form::text('meta_title',null,array('placeholder'=>'Title','id'=>'meta_title'))); ?>

    <span class="error meta_title"></span>
  </div>
  <div class="field">
    <label>Meta Content</label>
    <?php echo e(Form::textarea('meta_content',null,array('placeholder'=>'Content','id'=>'meta_content','rows'=>3))); ?>

    <span class="error meta_content"></span>
  </div>
  <button class="ui button primary" type="submit">Save</button>
  <button class="ui button" type="button" onclick="goBack()">Back</button>
</div>
<?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
  $(document).ready(function() {
    $('.summernote').summernote({
      height:300
    });
  });

  $("#template-form").on('submit',function(e){
    e.preventDefault();
    $(".segment").addClass('loading');
    $(".error").html("");
        $.ajax({
            url: '<?php echo route('pages.add',$id); ?>',
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) { 
              $(".segment").removeClass('loading');
              if(data.status==true){
                window.location.href = '<?php echo route('pages.index'); ?>';
              }else{
                swal("Oh noez!",data.message, "error");
              }
            },
            error: function (data) {
              $(".segment").removeClass('loading');
              var response = JSON.parse(data.responseText); 
              $.each(response.errors, function (k, v) {
                  $("." + k).html(v);
              }); 
            }
        });
  })
  $("#title").keyup(function(){
      var Text = $(this).val();
      Text = convertToSlug($.trim(Text));
      $("#slug").val(Text);    
  });
  $("#title").change(function(){
      var Text = $(this).val();
      Text = convertToSlug($.trim(Text));
      $("#slug").val(Text);    
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>