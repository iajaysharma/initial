<?php $__env->startSection('content'); ?>
<!-- Start Page Content -->
<div class="row">
	<!-- Column -->
	<div class="col-lg-6">
		<div class="ui segment">
			<div class="box-two">
				<div class="avatar text-center">
					<?php if($profile->profile_image): ?>
					<img alt="<?php echo e($profile->username); ?>" style="max-height: 150px;" src="<?php echo e(url($profile->profile_image)); ?>">
					<?php endif; ?>
				</div>
				<h3 class="text-center"><?php echo e($profile->name); ?></h3>
				<div style="text-align: center" class="card-body">
					<div class="row">
						<div class="col-md-6 col-xs-6 b-r"> <strong>Name</strong>
							<br>
							<p class="text-muted"><?php echo e($profile->name); ?></p>
						</div>
						<div class="col-md-6 col-xs-6"> <strong>Location</strong>
							<br>
							<p class="text-muted"><?php echo e($profile->country->name); ?></p>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6 col-xs-6 b-r"> <strong>Email</strong>
							<br>
							<p class="text-muted"><?php echo e($profile->email); ?></p>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		<div class="ui segments">
			<div class="ui segment">
				<p>Change Password</p>
			</div>
			<div class="ui secondary segment">
				<form class="ui form" id="change-password">
					<?php echo e(csrf_field()); ?>

					<div class="field">
						<label>Current Password</label>
						<input type="password" class="blank" name="current_password" placeholder="Current Password">
						<span class="error current_password"></span>
					</div>
					<div class="field">
						<label>New Password</label>
						<input type="password" class="blank" name="new_password" placeholder="New Password">
						<span class="error new_password"></span>
					</div> 
					<button class="ui button primary btn-block" type="submit">Submit</button>
				</form>
			</div>
		</div>
	</div>
	<!-- Column -->
	<!-- Column -->
	<div class="col-lg-6">
		<div class="box dark">
			<div class="body">
				<?php echo e(Form::model($profile,array('files'=>true,'class'=>'form-horizontal ui form'))); ?>

				<div class="form-group">
					<label class="col-md-12">Profile Image</label>
					<div class="row">
						<div class="col-md-7 ">
							<div class="form-control" style="margin-left:12px;">
								<input name="profile_image" id="profile_image" class="" type="file">
							</div>
							<span class="text-danger"><?php echo e($errors->first('profile_image')); ?></span>
						</div>
						<?php if($profile->profile_image): ?>
						<div class="col-md-4">
							<img class="img-responsive img-thumbnail" alt="<?php echo e($profile->username); ?>" src="<?php echo e(url($profile->profile_image)); ?>">
						</div>
						<?php endif; ?>
					</div>
				</div>
				
				<div class="form-group">
					<label class="col-md-12">Name</label>
					<div class="col-md-12">
						<?php echo e(Form::text('name',null,array('class'=>'','placeholder'=>'Name'))); ?>

						<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
					</div>
				</div>
				<div class="form-group">
					<label for="example-email" class="col-md-12">Email</label>
					<div class="col-md-12">
						<?php echo e(Form::email('email',null,array('class'=>'','placeholder'=>'Email'))); ?>

						<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-12">Select Country</label>
					<div class="col-sm-12">
						<?php echo e(Form::select('country_id',$countries,null,array('class'=>''))); ?>

						<span class="text-danger"><?php echo e($errors->first('country_id')); ?></span>
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-12">
						<button class="ui button primary btn-block">Update Profile</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
	$("#change-password").on('submit',function(e){
		e.preventDefault();
	    $(".secondary").addClass('loading');
	    $(".error").html("");
	    $.ajax({
	        url: baseUrl+'/admin/update-password',
	        type: "POST",
	        data: new FormData(this),
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (data) { 
	            $(".segment").removeClass('loading');
	            if(data.status==true){                  
	            	$(".blank").val('');
	                swal("Ohh!!Yes",data.message,"success");
	            }else{
	                swal("Ohh!!No",data.message,"error");
	            }
	        },
	        error: function (data) {
	            $(".segment").removeClass('loading');
	            var response = JSON.parse(data.responseText); 
	            $.each(response.errors, function (k, v) {
	                $("." + k).html(v);
	            }); 
	        }
	    });    
	});
</script>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>