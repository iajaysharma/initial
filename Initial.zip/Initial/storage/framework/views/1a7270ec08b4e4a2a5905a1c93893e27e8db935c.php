<footer class="Footer bg-dark dker">
	<?php if(isset($site_settings['website_copyright'])): ?>
	<p><?php echo e($site_settings['website_copyright']); ?></p>
	<?php else: ?>
	<p><?php echo e(date('Y')); ?> &copy; All Right Reserve.</p>
	<?php endif; ?>
</footer>