<div id="top">
    <nav class="navbar navbar-inverse navbar-static-top">
        <div class="container-fluid">
            
            
            <!-- Brand and toggle get grouped for better mobile display -->
            <header class="navbar-header">
                
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                </button>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="navbar-brand">
                    <?php if($site_settings['site_logo'] && file_exists($site_settings['site_logo'])): ?>
                    <img src="<?php echo e(url($site_settings['site_logo'])); ?>" style="max-height: 50px; margin-left: 15px;" alt="">
                    <?php else: ?>
                    <img src="<?php echo e(url('public/admin/assets/img/logo.png')); ?>" alt="">
                    <?php endif; ?>
                </a>
                
            </header>
            
            <div class="topnav">
                
                <div class="btn-group">
                    <a data-placement="bottom" data-original-title="Fullscreen" data-toggle="tooltip"
                        class="btn btn-default btn-sm" id="toggleFullScreen">
                        <i class="glyphicon glyphicon-fullscreen"></i>
                    </a>
                </div>
                <div class="btn-group">
                    <a href="<?php echo e(route('admin.profile')); ?>" data-toggle="tooltip" data-original-title="Edit Profile" data-placement="bottom" class="btn btn-primary btn-sm">
                        <i class="fa fa-user"></i>&nbsp;<?php echo e(Auth::guard('admin')->user()->name); ?>

                    </a>
                </div>
                <div class="btn-group">
                    <a data-placement="bottom" data-original-title="Show / Hide Left" data-toggle="tooltip"
                        class="btn btn-primary btn-sm toggle-left" id="menu-toggle">
                        <i class="fa fa-bars"></i>
                    </a>
                </div>
                <div class="btn-group">
                    <a href="<?php echo e(route('admin.logout')); ?>" data-toggle="tooltip" data-original-title="Logout" data-placement="bottom" class="btn btn-metis-1 btn-sm">
                        <i class="fa fa-power-off"></i>
                    </a>
                </div>
                
            </div>
            
            <!--<div class="collapse navbar-collapse navbar-ex1-collapse">
                
                <ul class="nav navbar-nav">
                    <li><a href="dashboard.html">Dashboard</a></li>
                    <li><a href="table.html">Tables</a></li>
                    <li class='dropdown '>
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            Form Elements <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="form-general.html">General</a></li>
                            <li><a href="form-validation.html">Validation</a></li>
                            <li><a href="form-wysiwyg.html">WYSIWYG</a></li>
                            <li><a href="form-wizard.html">Wizard &amp; File Upload</a></li>
                        </ul>
                    </li>
                </ul>
            </div>-->
        </div>
        <!-- /.container-fluid -->
    </nav>
    <!-- /.navbar -->
    <header class="head">
        <div class="search-bar">
            
            <!-- /.main-search -->

            <div class="dropdown">
                <button class="btn btn-default btn-block dropdown-toggle user-dropdown" type="button" data-toggle="dropdown">
                    <?php if(Auth::guard('admin')->user()->profile_image && file_exists(Auth::guard('admin')->user()->profile_image)): ?>
                    <img src="<?php echo e(url(Auth::guard('admin')->user()->profile_image)); ?>" style="max-height: 22px;" alt="">&nbsp;
                    <?php endif; ?>
                    <?php echo e(Auth::guard('admin')->user()->name); ?>

                <span class="caret"></span></button>
                <ul class="dropdown-menu" style="width: 100%;">
                    <li><a href="<?php echo e(route('admin.profile')); ?>"><i class="fa fa-user"></i>&nbsp;Edit profile</a></li>
                    <li><a href="<?php echo e(route('admin.logout')); ?>"><i class="fa fa-key"></i>&nbsp;Logout</a></li>
                </ul>
            </div>
        </div>
        <!-- /.search-bar -->
        <div class="main-bar">
            <div class="row">
                <div class="col-md-4">
                    <h3><i class="fa fa-home"></i>&nbsp;Admin <?php echo e((isset($title))?$title:''); ?></h3>
                </div>
                <div class="col-md-8">
                    <?php if(isset($breadcrumbs)): ?>
                    <ol class="breadcrumb" style="margin: 0px;">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                        <?php if(count($breadcrumbs)>0){ ?>
                        <?php  foreach($breadcrumbs as $breadcrumb){ ?>
                        <?php if($breadcrumb['relation']=="link"){?>
                        <li class="breadcrumb-item"><a href="<?php echo e($breadcrumb['url']); ?>"><?php echo e($breadcrumb['name']); ?></a></li>
                        <?php }else{ ?>
                        <li class="breadcrumb-item active"><?php echo e($breadcrumb['name']); ?></li>
                        <?php } ?>
                        <?php } ?>
                        <?php } ?>
                    </ol>
                    <?php endif; ?>
                </div>
            </div>
            <!-- /.main-bar -->
        </header>
    </div>
    <!-- /.head -->