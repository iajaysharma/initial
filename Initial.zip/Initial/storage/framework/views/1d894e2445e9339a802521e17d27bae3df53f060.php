<?php $__env->startSection('content'); ?>
<div class="form-signin ">    
    <div class="tab-content ui segment">
        <div id="login" class="tab-pane active">
            <form id="admin-update-password" class="ui form">
                <p class="text-muted text-center">
                    <?php echo e($title); ?>

                </p>                
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                <input type="hidden" name="token" value=<?php echo e($token); ?>>
                <input type="password" placeholder="Password" name="password" class="form-control top">
                <span class="error password"></span>
                <br>
                <input type="password" style="margin-bottom: 0px;" name="password_confirmation" placeholder="Confirm Password" class="form-control bottom">
                <span class="error password_confirmation"></span> 
                <br>                 
                <button class="ui button primary btn-block submit-btn" type="submit">Change Password</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $("#admin-update-password").on('submit', (function (e) {
    e.preventDefault();
    $(".segment").addClass('loading');
    $(".error").html("");
    $.ajax({
        url: baseUrl+'/admin/change-password/<?php echo $token; ?>',
        type: "POST",
        data: new FormData(this),
        contentType: false,
        cache: false,
        processData: false,
        success: function (data) { 
            $(".segment").removeClass('loading');
            if(data.status==true){                  
                window.location.href = baseUrl+'/admin';
            }else{
                swal("Ohh!!No",data.message,"error");
            }
        },
        error: function (data) {
            $(".segment").removeClass('loading');
            var response = JSON.parse(data.responseText); 
            $.each(response.errors, function (k, v) {
                $("." + k).html(v);
            }); 
        }
    });        

}));
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default-auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>