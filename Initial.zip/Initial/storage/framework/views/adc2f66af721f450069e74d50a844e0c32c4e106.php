<?php $__env->startSection('content'); ?>
<div class="container-fluid"> 
	<?php echo e(Form::model($data,array('url'=>url('admin/users/add/'.$id),'files'=>'true'))); ?>

    <div class="row">    	
        <div class="col-6">
            <div class="card">
                <div class="card-body">
                   <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                   		<label for="name">Name<span class="text-danger">*</span></label>
                   		<?php echo e(Form::text('name',null,array('class'=>'form-control','placeholder'=>'Name'))); ?>

                   		<span class="<?php echo e($errors->has('name') ? 'ti-alert text-danger text-danger' : ''); ?>"><?php echo e($errors->first('name')); ?></span>
                   </div>
                   <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                   		<label for="email">Email<span class="text-danger">*</span></label>
                   		<?php echo e(Form::text('email',null,array('class'=>'form-control','placeholder'=>'Email'))); ?>

                   		<span class="<?php echo e($errors->has('email') ? 'ti-alert text-danger' : ''); ?>"><?php echo e($errors->first('email')); ?></span>
                   </div>
                   <?php if(!$id): ?>
                   <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                   		<label for="password">Password<span class="text-danger">*</span></label>
                   		<?php echo e(Form::password('password',array('class'=>'form-control','placeholder'=>'password'))); ?>

                   		<span class="<?php echo e($errors->has('password') ? 'ti-alert text-danger' : ''); ?>"><?php echo e($errors->first('password')); ?></span>
                   </div>
                   <?php endif; ?>
                   <div class="form-group <?php echo e($errors->has('mobile') ? 'has-error' : ''); ?>">
                   		<label for="mobile">Mobile</label>
                   		<?php echo e(Form::text('mobile',null,array('class'=>'form-control','placeholder'=>'Mobile Number'))); ?>

                   		<span class="<?php echo e($errors->has('mobile') ? 'ti-alert text-danger' : ''); ?>"><?php echo e($errors->first('mobile')); ?></span>
                   </div>
                   <div class="form-group <?php echo e($errors->has('gender') ? 'has-error' : ''); ?>">
                   		<label for="gender">Gender</label> 
                   		<?php echo e(Form::select('gender',config('constants.GENDER'),null,array("class"=>"form-control custom-select",'placeholder'=>'Select Gender'))); ?>

                   		<span class="<?php echo e($errors->has('gender') ? 'ti-alert text-danger' : ''); ?>"><?php echo e($errors->first('gender')); ?></span>
                   </div> 
                   <div class="form-group <?php echo e($errors->has('dob') ? 'has-error' : ''); ?>">
                   		<label for="dob">Date of Birth</label>
                   		<?php echo e(Form::text('dob',null,array('class'=>'form-control','placeholder'=>'Date of Birth','data-provide'=>'datepicker','data-date-format'=>'dd-mm-yyyy'))); ?>

                   		<span class="<?php echo e($errors->has('dob') ? 'ti-alert text-danger' : ''); ?>"><?php echo e($errors->first('dob')); ?></span>
                   </div>
                   <div class="form-group <?php echo e($errors->has('country_id') ? 'has-error' : ''); ?>">
                   		<label for="country_id">Country<span class="text-danger">*</span></label> 
                   		<?php echo e(Form::select('country_id',$countries,null,array("class"=>"form-control custom-select",'placeholder'=>'Select Country'))); ?>

                   		<span class="<?php echo e($errors->has('country_id') ? 'ti-alert text-danger' : ''); ?>"><?php echo e($errors->first('country_id')); ?></span>
                   </div>
                   <div class="form-group <?php echo e($errors->has('status') ? 'has-error' : ''); ?>">
                   		<label for="status">Status<span class="text-danger">*</span></label> 
                   		<?php echo e(Form::select('status',config('constants.STATUS'),null,array("class"=>"form-control custom-select"))); ?>

                   		<span class="<?php echo e($errors->has('status') ? 'ti-alert text-danger' : ''); ?>"><?php echo e($errors->first('status')); ?></span>
                   </div>
                </div>
            </div>
        </div>
        <div class="col-6">
            <div class="card">
                <div class="card-body">
                	<div class="form-group <?php echo e($errors->has('short_bio') ? 'has-error' : ''); ?>">
                   		<label for="short_bio">Short Bio</label>
                   		<?php echo e(Form::text('short_bio',null,array('class'=>'form-control','placeholder'=>'Short Bio','maxlength'=>300))); ?>

                   		<span class="text-info">Max 300 characters allowed</span>
                   		<span class="<?php echo e($errors->has('short_bio') ? 'ti-alert text-danger' : ''); ?>"><?php echo e($errors->first('short_bio')); ?></span>
                   </div>
                   <div class="form-group <?php echo e($errors->has('website') ? 'has-error' : ''); ?>">
                   		<label for="website">Website</label>
                   		<?php echo e(Form::url('website',null,array('class'=>'form-control','placeholder'=>'Website'))); ?>

                   		<span class="<?php echo e($errors->has('website') ? 'ti-alert text-danger' : ''); ?>"><?php echo e($errors->first('website')); ?></span>
                   </div>
                   <div class="form-group <?php echo e($errors->has('instagram_username') ? 'has-error' : ''); ?>">
                   		<label for="instagram_username">Instagram Username</label>
                   		<?php echo e(Form::text('instagram_username',null,array('class'=>'form-control','placeholder'=>'Instagram Username'))); ?>

                   		<span class="<?php echo e($errors->has('instagram_username') ? 'ti-alert text-danger' : ''); ?>"><?php echo e($errors->first('instagram_username')); ?></span>
                   </div>
                   <div class="form-group <?php echo e($errors->has('twitter_username') ? 'has-error' : ''); ?>">
                   		<label for="twitter_username">Twitter Username</label>
                   		<?php echo e(Form::text('twitter_username',null,array('class'=>'form-control','placeholder'=>'Twitter Username'))); ?>

                   		<span class="<?php echo e($errors->has('twitter_username') ? 'ti-alert text-danger' : ''); ?>"><?php echo e($errors->first('twitter_username')); ?></span>
                   </div>
                	<div for="image">Profile Picture</div>
                   <div class="input-group image-preview <?php echo e($errors->has('profile_picture') ? 'has-error' : ''); ?>">
		                <input type="text" class="form-control image-preview-filename" disabled="disabled">
		                <span class="input-group-btn">
		                    <button type="button" class="btn btn-danger image-preview-clear" style="display:none;">Clear</button>
		                    <div class="btn btn-secondary image-preview-input">
		                        <span class="image-preview-input-title">Browse</span>
		                        <input type="file" accept="image/png, image/jpeg, image/gif, image/jpg" name="profile_picture"/>
		                    </div>
		                </span>		                
		            </div>
		            <div class="form-group <?php echo e($errors->has('profile_picture') ? 'ti-alert text-danger' : ''); ?>"><?php echo e($errors->first('profile_picture')); ?></div>
		            <div class="form-group">
		            	<?php if(isset($data->profile_picture) && $data->profile_picture!="" && file_exists(public_path().'/upload/users/thumbnail_images/'.$data->profile_picture)): ?>
							<img src="<?php echo e(url('public/upload/users/thumbnail_images/'.$data->profile_picture)); ?>" class="img-thumbnail" alt="">
		            	<?php endif; ?>
		            </div>
		            <div class="form-group">
		            	<div class="btn-group">
		            		<button type="submit" class="btn btn-success">Save</button>&nbsp;
		            		<a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary">Cancel</a>
		            	</div>
		            </div>
                </div>
            </div>
        </div>        
    </div> 
    <?php echo e(Form::close()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>