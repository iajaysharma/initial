<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Models\Setting;
class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        view()->composer('*', function ($view) 
        {
            $settings = Setting::all();
            $site_settings = array();
            if(count($settings)>0){
                foreach ($settings as $key => $value) {
                    $site_settings[$value->field_name] = $value->value;
                }
            }
            $view->with('site_settings', $site_settings);

        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
