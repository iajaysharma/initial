<?php
namespace App\Lib;
use Illuminate\Database\Eloquent\Model;
use Mail;
/**
 * 
 * 
 * This Library use for image upload and resizing.
 *  
 * 
 **/

class Email
{
    
    public static function send($data)
    {
        // Send email
        Mail::send('emails.'.$data['templete'], ['data' => $data], function ($m) use ($data) {
          $m->from('jobkey@gmail.com', 'Vicarious');
          $m->to($data['email'], $data['name'])->subject($data['subject']);
        });
    }
    
}
