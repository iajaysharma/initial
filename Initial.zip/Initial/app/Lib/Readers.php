<?php
namespace App\Lib;
use Illuminate\Database\Eloquent\Model;
use Image;
use Illuminate\Support\Facades\Storage;
/**
 * 
 * 
 * This Library use for image upload and resizing.
 *  
 * 
 **/

class Readers
{
    
    public static function doRead($file,$path){
        $response = [];
        $fileTarget = $file;
        //echo $fileTarget->getClientOriginalExtension(); die;
        $file = time().'.'.$fileTarget->getClientOriginalExtension();
        $destinationPath = public_path().$path;
        //echo $file."<br>";
        //echo $destinationPath."/".$file; die;
        $extracted_plaintext = "";
        //dd($destinationPath);
        if($uploaded = $fileTarget->move($destinationPath, $file)){
            
            $filename = "/opt/lampp/htdocs/jobshark/public/documents/19/1530194588.doc";
            
            if (file_exists($filename) ){
                
                if(($fh = fopen($filename, 'r')) !== false ) {

                    $headers = fread($fh, 0xA00);

                    # 1 = (ord(n)*1) ; Document has from 0 to 255 characters
                    $n1 = ( ord($headers[0x21C]) - 1 );

                    # 1 = ((ord(n)-8)*256) ; Document has from 256 to 63743 characters
                    $n2 = ( ( ord($headers[0x21D]) - 8 ) * 256 );

                    # 1 = ((ord(n)*256)*256) ; Document has from 63744 to 16775423 characters
                    $n3 = ( ( ord($headers[0x21E]) * 256 ) * 256 );

                    # (((ord(n)*256)*256)*256) ; Document has from 16775424 to 4294965504 characters
                    $n4 = ( ( ( ord($headers[0x21F]) * 256 ) * 256 ) * 256 );

                    # Total length of text in the document
                    $textLength = ($n1 + $n2 + $n3 + $n4);

                    $extracted_plaintext = fread($fh, $textLength);

                    # if you want the plain text with no formatting, do this


        //            if (strpos($extracted_plaintext, 'save') !== false) {
        //                echo 'true';
        //            } 

                    //echo nl2br($extracted_plaintext);

                    //echo $extracted_plaintext; die;
                }

            }            
            //chmod(public_path(),0777);
            $response['status']     = true;
            $response['url']       = "public".$path.$file;
            $response['content']    = $extracted_plaintext;
            $response['path']       = $path;
        }else{
            $response['status']     = false;
        }
        return $response;

    }
    
}
