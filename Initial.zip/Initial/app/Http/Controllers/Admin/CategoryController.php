<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use Session;
use Image;
use App\Lib\Helper;
use App\Models\Category;
class CategoryController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */    

    public function index(Request $request){
        $title = "Categories";
        $breadcrumbs = [
            ['name'=>'Categories','url'=>url('admin/category'),'relation'=>'current'],
        ];   
        return view('admin.category.index',compact('breadcrumbs','title'));
    }

    public function datatables(Request $request){
        $columns = array(
                0 =>'id', 
                1 =>'name',
                2 =>'slug', 
                3 =>'description', 
                4 =>'photo',
                5=> 'status',
                6=> 'action',
            );
       

        $totalData = Category::where('status','!=',2)->count();
        $totalFiltered = $totalData; 
        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        if(empty($request->input('search.value')))
        {            
            $posts = Category::where('status','!=',2)->offset($start)
                ->limit($limit)
                ->orderBy($order,$dir)
                ->get();
        }
        else
        {
            $search = $request->input('search.value'); 
            $posts = Category::where(function($query) use ($search){
                        $query->where('id','LIKE',"%{$search}%")                        
                         ->orWhere('name','LIKE',"%{$search}%")
                          ->orWhere('slug','LIKE',"%{$search}%");
                        }) 
                    ->where('status','!=',2)                           
                    ->offset($start)
                    ->limit($limit)
                    ->orderBy($order,$dir)
                    ->get();

            $totalFiltered = Category::where(function($query) use ($search){
                $query->where('id','LIKE',"%{$search}%")               
                 ->orWhere('name','LIKE',"%{$search}%")
                  ->orWhere('slug','LIKE',"%{$search}%");
                })
                ->where('status','!=',2)
                ->count();
        }
        $data = array();
        if(!empty($posts))
        {
            foreach ($posts as $list)
            {
                $nestedData['id'] = $list->id;
                $nestedData['status'] = Helper::getStatus($list->status,$list->id);
                $nestedData['name'] =  ucfirst($list->name);
                $nestedData['slug'] =  $list->slug; 
                $nestedData['description'] =  $list->description; 
                $nestedData['action'] =  Helper::getButtons([
                                ['key'=>'Edit','link'=>route('category.add',$list->id)],
                                ['key'=>'Delete','link'=>$list->id],
                            ]);
                if($list->photo!="" && file_exists(public_path().'/upload/category/thumbnail_images/'.$list->photo)){
                    $path = url('public/upload/category/thumbnail_images/'.$list->photo);                    
                }else{
                    $path = url('public/images/no-image.png');
                }
                $nestedData['photo'] = "<img src='$path' style='max-height:100px;' alt='No Image'>";
                $data[] = $nestedData; 
            }
        }

      $json_data = array(
                "draw"            => intval($request->input('draw')),  
                "recordsTotal"    => intval($totalData),  
                "recordsFiltered" => intval($totalFiltered), 
                "data"            => $data   
                );
        echo json_encode($json_data); 
    }

    public function status(Request $request)
    {
        $id = $request->id;
        $row  = Category::whereId($id)->first();
        $row->status =  $row->status=='1'?'0':'1';
        $row->save();
        $html = '';
        switch ($row->status) {
          case '1':
               $html =  '<a data-toggle="tooltip" style="color:#fff"  class="btn btn-success btn-xs" title="Active" onClick="changeStatus('.$id.')" >Active</a>';
              break;
               case '0':
               $html =  '<a data-toggle="tooltip" style="color:#fff"  class="btn btn-danger btn-xs" title="Inactive" onClick="changeStatus('.$id.')" >InActive</a>';
              break;
               case '2':
               $html =  '<a data-toggle="tooltip" style="color:#fff" class="btn btn-danger btn-xs" title="Inactive" onClick="changeStatus('.$id.')" >InActive</a>';
              break;
          
          default:
            
              break;
      }
      return $html;

    }    
    
    public function delete(Request $request)
    {
        $id = $request->id;
        try{
            $delete = Category::where('id','=',$id)->update(['status'=>2]);   
            if($delete){
                echo json_encode(["type"=>"success","data"=>"Record Deleted"]); 
            }else{
                echo json_encode(["type"=>"error","data"=>"Could not deleted Record"]); 
            }
        }catch(\Exception $e){
            echo json_encode(["type"=>"error","data"=>$e->getMessage()]);   
        }
    }

    public function add(Request $request,$id=null){
        $title = "Add New Category";
        $breadcrumbs = [
            ['name'=>'Category','url'=>url('admin/category'),'relation'=>'Link'],
            ['name'=>'Add New Category','url'=>'','relation'=>'current'],
        ]; 
        if($id){
            $data = Category::find($id);
            if(!$data){
                Session::flash('danger','Invalid Request');
                return redirect(route('category.index'));
            }
        }else{
            $data = array();
        }
        if($request->isMethod('post')){
            $inputs = $request->except('slug');
            $inputs['slug'] = str_slug($request->get('slug'),'-');
            $validator = Category::validate($inputs,$id);
            if($validator->fails()){
                Session::flash('danger','Please correct errors');
                return back()->withErrors($validator)->withInput($inputs);
            }else{
                $formData = $request->except('photo','slug');
                $formData['slug'] = str_slug($request->get('slug'),'-');
                if ($request->hasFile('photo')) {
                    if($request->file('photo')->isValid()) {
                        try {
                            $photo = $request->file('photo');
                            $imagename = time().'.'.$photo->getClientOriginalExtension(); 
                            
                            // Upload in thumbnail
                            $destinationPath = public_path('upload/category/thumbnail_images');
                            $thumb_img = Image::make($photo->getRealPath());
                            $thumb_img->resize(80, 80, function ($constraint) {
                                $constraint->aspectRatio();
                            });
                            $thumb_img->save($destinationPath.'/'.$imagename,80);

                            // Upload in medium
                            $destinationPath = public_path('upload/category/medium_images');
                            $thumb_img = Image::make($photo->getRealPath());
                            $thumb_img->resize(300, 300, function ($constraint) {
                                $constraint->aspectRatio();
                            });
                            $thumb_img->save($destinationPath.'/'.$imagename,80);   

                            // upload in original photo         
                            $destinationPath = public_path('upload/category/normal_images');
                            $photo->move($destinationPath, $imagename);
                            $formData['photo'] = $imagename;
                        } catch (\Exception $e) {
                            Session::flash('message',$e->getMessage());
                            return back()->withInput($request->except('photo','password'));
                        }
                    }   
                }
                if($id){
                    try{
                        $data->update($formData);
                        Session::flash('success','Record updated successfully');
                        return redirect(route('category.index'));
                    }catch(Exception $e){
                        Session::flash('danger',$e->getMessage());
                        return redirect(route('category.index'));
                    }    
                }else{
                    $user = Category::create($formData);
                    if($user){
                        Session::flash('success','Category added successfully');
                        return redirect(route('category.index'));
                    }else{
                        Session::flash('success','Category could not be added! Please try again');
                        return redirect(route('category.index'));
                    }
                }
            }
        }
        return view('admin.category.add',compact('title','breadcrumbs','data','id'));
    }
}
