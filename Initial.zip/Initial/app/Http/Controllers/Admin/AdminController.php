<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use Session;
use App\Models\Admin;
use App\Models\User;
use App\Models\Country;
use App\Models\Template;
use App\Models\Page;
use App\Models\Setting;
use App\Lib\Uploader;
use Validator;
use Mail;
use Hash;
class AdminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:admin',['except'=>['reset_password','change_password']]);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function dashboard()
    {
        //dd(Session::get('site_settings'));
        $title = "Dashboard";
        $users = User::count();            
        $templates = Template::count();            
        $pages = Page::count();            
        return view('admin.pages.dashboard',compact('title','users','templates','pages'));
    }

    public function logout(Request $request)
    {
        Auth::guard('admin')->logout(); 
        return redirect(route( 'admin.login' ));
    }

    public function profile(Request $request){
        $title = "Profile";
        $breadcrumbs = [
            ['name'=>'Profile','url'=>url('admin/profile'),'relation'=>'current'],
        ];  
        if($request->isMethod('post')){
            $validator = Admin::validate($request->all(),Auth::guard('admin')->user()->id);
            if($validator->fails()){
                return back()->withErrors($validator)->withInput($request->except('profile_image'));
            }else{
                $formData = $request->except('profile_image');
                if ($request->hasFile('profile_image')) {
                    if($request->file('profile_image')->isValid()) { 
                        // This is use for upload image.
                        $path = "/uploads/profile/";
                        $responseData =  Uploader::doUpload($request->file('profile_image'),$path);
                        $formData['profile_image'] = $responseData['file'];
                    }
                }
                try{ 
                    $data = Admin::find(Auth::guard('admin')->user()->id); 
                    $data->update($formData);
                    Session::flash('success','Profile updated successfully.');
                    return redirect(route('admin.profile'));
                }catch(\Exception $e){
                    Session::flash('danger',$e->getMessage());
                    return redirect(route('admin.profile'));
                }    
            }

        }
        $countries = Country::pluck('name','id');   
        $profile = Admin::where('id','=',Auth::guard('admin')->user()->id)->with(['country'])->first();
        return view('admin.pages.profile',compact('countries','profile','breadcrumbs','title'));
    }

    public function reset_password(Request $request){ 
        if($request->ajax() && $request->isMethod('post')){
            try {
                $rules = ['email' => 'required|email|exists:admin'];
                $validator = Validator::make($request->all(), $rules);
                if ($validator->fails()) {
                    return response()->json(array('errors' => $validator->messages()), 422);
                }else {
                    $user_data = Admin::where('email',$request->get('email'))->first();
                    $email = $user_data->email;
                    $token = str_random(40);
                    $user_data->update(['token'=>$token]);
                    $mail_data = Template::where('slug', '=', 'user-forgot-password')->first();
                    $site_setting = Setting::pluck('value','field_name');
                    if($mail_data){  
                        $site_email      = $site_setting['site_email'];
                        $site_title      = $site_setting['site_title'];
                        $link = '<a class="btn-mail" href="'.url('admin/change-password/'.$token).'">Click for Reset password</a>';
                        if($mail_data and $email){
                            $message        =   str_replace(array('{NAME}', '{LINK}', '{SITE_TITLE}'), array($user_data->name, $link, $site_title), $mail_data->content);
                            $subject        = $mail_data->title;
                            
                            Mail::send('email.email', array('data'=>$message), function($message) use ($site_email, $email, $subject, $site_title){ 
                                $message->from($site_email, $site_title);
                                $message->to($email, $email)->subject($subject);
                            });
                            return ['status' => true, 'message' => "Password reset link has been sent to your email."];
                        }else{
                            return ['status' => false, 'message' => "Error while sending email, please try again"];
                        }                    
                    }else{
                        return ['status' => false, 'message' => "Email template not found"];
                    }
                }
            } catch (\Exception $e) {
                return ['status' => false, 'message' => $e->getMessage()];
            }
        }
    }

    public function change_password(Request $request,$token=null){ 
        $title = "Change Password";
        $admin = Admin::where('token',$token)->first();
        if($admin){
            if($request->ajax() && $request->isMethod('post')){
                try {      
                    $rules = [
                        'token'    => 'required',   
                        'password' => 'required|min:8',
                        'password_confirmation' => 'required_with:password|same:password|min:8'
                    ];
                    $validator = Validator::make($request->all(), $rules);
                    if ($validator->fails()) {
                        return response()->json(array('errors' => $validator->messages()), 422);
                    }else{
                       $password = Hash::make($request->get('password'));
                       $admin->update(['password'=>$password]);
                        Session::flash('success','Password chagned successfully');
                        return ['status' => true, 'message' => 'Password chagned successfully']; 
                    }
                } catch (\Exception $e) {
                    return ['status' => false, 'message' => $e->getMessage()];   
                }
            }
            return view('admin.auth.change_password',compact('data','token','title'));
        }else{
            Session::flash('danger','Invalid Token');
            return ['status' => false, 'message' => 'Token is required']; 
        }
    }

    public function update_password(Request $request){         
        if($request->ajax() && $request->isMethod('post')){
            try {      
                $rules = [
                    'current_password'      => 'required',   
                    'new_password'          => 'required|min:8'
                ];
                $validator = Validator::make($request->all(), $rules);
                if ($validator->fails()) {
                    return response()->json(array('errors' => $validator->messages()), 422);
                }else{
                   $admin = Admin::where('id',Auth::guard('admin')->user()->id)->first();
                   $password = Hash::make($request->get('current_password'));
                   $new_password = Hash::make($request->get('new_password'));
                   if(Hash::check($request->get('current_password'), $admin->password)){
                        $admin->update(['password'=>$new_password]);
                        return ['status' => true, 'message' => 'Password chagned successfully']; 
                   }else{
                        return ['status' => false, 'message' => 'Current password is invalid'];
                   } 
                }
            } catch (\Exception $e) {
                return ['status' => false, 'message' => $e->getMessage()];   
            }
        }
    }
}
