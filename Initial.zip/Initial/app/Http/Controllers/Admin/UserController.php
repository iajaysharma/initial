<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use Session;
use App\Models\Admin;
use App\Models\Country;
use App\Models\User; 
use App\Lib\Helper;
class UserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */    

    public function index(Request $request){
        $title = "Users";
        $breadcrumbs = [
            ['name'=>'Users','url'=>url('admin/users'),'relation'=>'current'],
        ];   
        return view('admin.users.index',compact('breadcrumbs','title'));
    }

    public function datatables(Request $request){
        $columns = array(
                0 =>'id', 
                1 =>'name',
                2 =>'email', 
                3 =>'created_at',
                4=> 'status',
                5=> 'action',
            );
       

        $totalData = User::count();
        $totalFiltered = $totalData; 
        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        if(empty($request->input('search.value')))
        {            
            $posts = User::offset($start)
                ->limit($limit)
                ->orderBy($order,$dir)
                ->get();
        }
        else
        {
            $search = $request->input('search.value'); 
            $posts = User::where(function($query) use ($search){
                        $query->where('id','LIKE',"%{$search}%")                        
                         ->orWhere('name','LIKE',"%{$search}%")
                          ->orWhere('email','LIKE',"%{$search}%");
                        })                            
                    ->offset($start)
                    ->limit($limit)
                    ->orderBy($order,$dir)
                    ->get();

            $totalFiltered = User::where(function($query) use ($search){
                                $query->where('id','LIKE',"%{$search}%")                               
                                 ->orWhere('name','LIKE',"%{$search}%")
                                  ->orWhere('email','LIKE',"%{$search}%");
                                })
                                ->count();
            
        }
        $data = array();
        if(!empty($posts))
        {
            foreach ($posts as $list)
            {
                $nestedData['id'] = $list->id;
                $nestedData['created_at'] = date('d M Y h:ia',strtotime($list->created_at));
                $nestedData['status'] = Helper::getStatus($list->status,$list->id);
                $nestedData['email'] =  $list->email;
                $nestedData['name'] =  ucfirst($list->name); 
                $nestedData['action'] =  Helper::getButtons([
                                ['key'=>'View','link'=>route('users.view',$list->id)],
                                ['key'=>'Delete','link'=>$list->id],
                            ]);
                $data[] = $nestedData; 
            }
        }

      $json_data = array(
                "draw"            => intval($request->input('draw')),  
                "recordsTotal"    => intval($totalData),  
                "recordsFiltered" => intval($totalFiltered), 
                "data"            => $data   
                );
        echo json_encode($json_data); 
    }

    public function status(Request $request)
    { 
        $user_id = $request->user_id; 
        $row  = User::whereId($user_id)->first();
        $row->status =  $row->status=='1'?'0':'1';
        $row->save();
        $html = '';
        switch ($row->status) {
          case '1':
               $html =  '<a data-toggle="tooltip" style="color:#fff"  class="btn btn-success btn-xs" title="Active" onClick="changeStatus('.$user_id.')" >Active</a>';
              break;
               case '2':
               $html =  '<a data-toggle="tooltip" style="color:#fff"  class="btn btn-danger btn-xs" title="Inactive" onClick="changeStatus('.$user_id.')" >UnVerified</a>';
              break;
               case '0':
               $html =  '<a data-toggle="tooltip" style="color:#fff" class="btn btn-danger btn-xs" title="Inactive" onClick="changeStatus('.$user_id.')" >InActive</a>';
              break;
          
          default:
            
              break;
      }
      return $html;
    }    
    
    public function delete(Request $request)
    {
        $user_id = $request->user_id;
        try{
            $delete = User::where('id','=',$user_id)->delete();   
            if($delete){
                echo json_encode(["type"=>"success","data"=>"Record Deleted"]); 
            }else{
                echo json_encode(["type"=>"error","data"=>"Could not deleted Record"]); 
            }
        }catch(\Exception $e){
            echo json_encode(["type"=>"error","data"=>$e->getMessage()]);   
        }
    }

    public function view($id){
        if(!$id){
            Session::flash('danger','Invalid Request');
            return redirect(route('users.index'));
        }
        $data = User::where('id',$id)->with(['country'])->first();
        if($data){
            $title = "User Profile View";
            $breadcrumbs = [
                ['name'=>'Users','url'=>url('admin/users'),'relation'=>'Link'],
                ['name'=>'View','url'=>'','relation'=>'current'],
            ]; 
            return view('admin.users.view',compact('title','breadcrumbs','data'));
        }else{
            Session::flash('danger','Invalid Request');
            return redirect(route('users.index'));
        }
    }
}
