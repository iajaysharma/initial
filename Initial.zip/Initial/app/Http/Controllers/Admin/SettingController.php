<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use Session; 
use App\Models\Setting; 
use App\Lib\Helper;
use App\Lib\Uploader;
class SettingController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */    

    public function index(Request $request){
        $title = "Settings";
        $breadcrumbs = [
            ['name'=>'Settings','url'=>url('admin/settings'),'relation'=>'current'],
        ];   
        return view('admin.settings.index',compact('breadcrumbs','title'));
    }

    public function datatables(Request $request){
        $columns = array(
                0 =>'id', 
                1 =>'field_title',
                2 =>'field_name', 
                3 =>'field_type', 
                4 =>'value',
                5=> 'action',
            );
       

        $totalData = Setting::count();
        $totalFiltered = $totalData; 
        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        if(empty($request->input('search.value')))
        {            
            $posts = Setting::offset($start)
                ->limit($limit)
                ->orderBy($order,$dir)
                ->get();
        }
        else
        {
            $search = $request->input('search.value'); 
            $posts = Setting::where(function($query) use ($search){
                        $query->where('id','LIKE',"%{$search}%")                        
                         ->orWhere('field_title','LIKE',"%{$search}%")
                          ->orWhere('field_name','LIKE',"%{$search}%");
                        })                            
                    ->offset($start)
                    ->limit($limit)
                    ->orderBy($order,$dir)
                    ->get();

            $totalFiltered = Setting::where(function($query) use ($search){
                                $query->where('id','LIKE',"%{$search}%")                               
                                 ->orWhere('field_title','LIKE',"%{$search}%")
                                  ->orWhere('field_name','LIKE',"%{$search}%");
                                })
                                ->count();
            
        }
        $data = array();
        if(!empty($posts))
        {
            foreach ($posts as $list)
            {
                $nestedData['id'] = $list->id; 
                $nestedData['field_title'] =  ucfirst($list->field_title);
                $nestedData['field_type'] =  ucfirst($list->field_type);
                $nestedData['field_name'] =  $list->field_name;  
                if($list->field_type=="image"){
                    $nestedData['value'] = '<img src="'.url($list->value).'" style="max-height:75px;" alt="">';
                }else{
                     $nestedData['value'] = $list->value;
                }
                $nestedData['action'] =  Helper::getButtons([
                                ['key'=>'Edit','link'=>route('settings.add',$list->id)]
                            ]);
                $data[] = $nestedData; 
            }
        }

      $json_data = array(
                "draw"            => intval($request->input('draw')),  
                "recordsTotal"    => intval($totalData),  
                "recordsFiltered" => intval($totalFiltered), 
                "data"            => $data   
                );
        echo json_encode($json_data); 
    }    
    
    public function delete(Request $request)
    {
        $user_id = $request->user_id;
        try{
            $delete = Setting::where('id','=',$user_id)->delete();   
            if($delete){
                echo json_encode(["type"=>"success","data"=>"Record Deleted"]); 
            }else{
                echo json_encode(["type"=>"error","data"=>"Could not deleted Record"]); 
            }
        }catch(\Exception $e){
            echo json_encode(["type"=>"error","data"=>$e->getMessage()]);   
        }
    }

    public function add(Request $request, $id=null){ 
        $title = "Add Site Setting";
        $breadcrumbs = [
            ['name'=>'Site Settings','url'=>url('admin/settings'),'relation'=>'link'],
            ['name'=>'Add Site Setting','url'=>'','relation'=>'current'],
        ];
        $data = ($id)?Setting::find($id):array();
        if($request->ajax() && $request->isMethod('post')){
            try {
                $validator = Setting::validate($request->all(),$id);
                if($validator->fails()){
                    return response()->json(array('errors' => $validator->messages()), 422);
                }else{
                    $formData = $request->except('value');
                    if($request->field_type=="image"){
                        if ($request->hasFile('value')) {
                            if(substr($request->file('value')->getMimeType(), 0, 5) == 'image') { 
                                // This is use for upload image.
                                $path = "/uploads/settings/";
                                $responseData =  Uploader::doUpload($request->file('value'),$path);
                                $formData['value'] = $responseData['file'];
                            }else{
                                return ['status' => false, 'message' => 'The file must be an image'];
                                exit();
                            }
                        }
                    }else{
                        $formData['value'] = $request->get('value');
                    }
                    if($id){                        
                        $data->update($formData);
                        Session::flash('success','Setting updated successfully');
                    }else{
                        Setting::create($formData);
                        Session::flash('success','Setting created successfully');
                    }
                    return ['status' => true, 'message' => 'Records updated successfully'];                  
                }
            } catch (\Exception $e) {
                return ['status' => false, 'message' => $e->getMessage()];
            }            
        }
        return view('admin.settings.add',compact('data','id','title','breadcrumbs'));
    }
}
