<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use Session; 
use App\Models\Template; 
use App\Lib\Helper;
class TemplateController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */    

    public function index(Request $request){
        $title = "Email Template";
        $breadcrumbs = [
            ['name'=>'Email Template','url'=>url('admin/templates'),'relation'=>'current'],
        ];   
        return view('admin.templates.index',compact('breadcrumbs','title'));
    }

    public function datatables(Request $request){
        $columns = array(
                0 =>'id', 
                1 =>'title',
                2 =>'slug', 
                3 =>'keys',
                4 =>'created_at',
                5=> 'action',
            );
       

        $totalData = Template::count();
        $totalFiltered = $totalData; 
        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        if(empty($request->input('search.value')))
        {            
            $posts = Template::offset($start)
                ->limit($limit)
                ->orderBy($order,$dir)
                ->get();
        }
        else
        {
            $search = $request->input('search.value'); 
            $posts = Template::where(function($query) use ($search){
                        $query->where('id','LIKE',"%{$search}%")                        
                         ->orWhere('title','LIKE',"%{$search}%")
                          ->orWhere('slug','LIKE',"%{$search}%");
                        })                            
                    ->offset($start)
                    ->limit($limit)
                    ->orderBy($order,$dir)
                    ->get();

            $totalFiltered = Template::where(function($query) use ($search){
                                $query->where('id','LIKE',"%{$search}%")                               
                                 ->orWhere('title','LIKE',"%{$search}%")
                                  ->orWhere('slug','LIKE',"%{$search}%");
                                })
                                ->count();
            
        }
        $data = array();
        if(!empty($posts))
        {
            foreach ($posts as $list)
            {
                $nestedData['id'] = $list->id;
                $nestedData['created_at'] = date('d M Y h:ia',strtotime($list->created_at));
                $nestedData['title'] =  ucfirst($list->title);
                $nestedData['slug'] =  $list->slug; 
                $nestedData['keys'] =  $list->keys; 
                $nestedData['action'] =  Helper::getButtons([
                                ['key'=>'Edit','link'=>route('templates.add',$list->id)]
                            ]);
                $data[] = $nestedData; 
            }
        }

      $json_data = array(
                "draw"            => intval($request->input('draw')),  
                "recordsTotal"    => intval($totalData),  
                "recordsFiltered" => intval($totalFiltered), 
                "data"            => $data   
                );
        echo json_encode($json_data); 
    }    
    
    public function delete(Request $request)
    {
        $user_id = $request->user_id;
        try{
            $delete = Template::where('id','=',$user_id)->delete();   
            if($delete){
                echo json_encode(["type"=>"success","data"=>"Record Deleted"]); 
            }else{
                echo json_encode(["type"=>"error","data"=>"Could not deleted Record"]); 
            }
        }catch(\Exception $e){
            echo json_encode(["type"=>"error","data"=>$e->getMessage()]);   
        }
    }

    public function add(Request $request, $id=null){
        $title = "Add New Email Template";
        $breadcrumbs = [
            ['name'=>'Email Templates','url'=>url('admin/templates'),'relation'=>'link'],
            ['name'=>'Add Email Template','url'=>'','relation'=>'current'],
        ];
        $data = ($id)?Template::find($id):array();
        if($request->ajax() && $request->isMethod('post')){
            try {
                $validator = Template::validate($request->all(),$id);
                if($validator->fails()){
                    return response()->json(array('errors' => $validator->messages()), 422);
                }else{
                    $formData = $request->all();
                    if($id){                        
                        $data->update($formData);
                        Session::flash('success','Template updated successfully');
                    }else{
                        Template::create($formData);
                        Session::flash('success','Template created successfully');
                    }
                    return ['status' => true, 'message' => 'Records updated successfully'];                  
                }
            } catch (\Exception $e) {
                return ['status' => false, 'message' => $e->getMessage()];
            }            
        }
        return view('admin.templates.add',compact('data','id','title','breadcrumbs'));
    }
}
