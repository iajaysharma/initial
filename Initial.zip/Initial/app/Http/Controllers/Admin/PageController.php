<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use Session; 
use App\Models\Page; 
use App\Lib\Helper;
class PageController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:admin',['except'=>['view']]);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */    

    public function index(Request $request){
        $title = "CMS Pages";
        $breadcrumbs = [
            ['name'=>'CMS Pages','url'=>url('admin/pages'),'relation'=>'current'],
        ];   
        return view('admin.pages.index',compact('breadcrumbs','title'));
    }

    public function datatables(Request $request){
        $columns = array(
                0 =>'id', 
                1 =>'title',
                2 =>'slug',
                3 =>'created_at',
                4=> 'action',
            );
       

        $totalData = Page::count();
        $totalFiltered = $totalData; 
        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        if(empty($request->input('search.value')))
        {            
            $posts = Page::offset($start)
                ->limit($limit)
                ->orderBy($order,$dir)
                ->get();
        }
        else
        {
            $search = $request->input('search.value'); 
            $posts = Page::where(function($query) use ($search){
                        $query->where('id','LIKE',"%{$search}%")                        
                         ->orWhere('title','LIKE',"%{$search}%")
                          ->orWhere('slug','LIKE',"%{$search}%");
                        })                            
                    ->offset($start)
                    ->limit($limit)
                    ->orderBy($order,$dir)
                    ->get();

            $totalFiltered = Page::where(function($query) use ($search){
                                $query->where('id','LIKE',"%{$search}%")                               
                                 ->orWhere('title','LIKE',"%{$search}%")
                                  ->orWhere('slug','LIKE',"%{$search}%");
                                })
                                ->count();
            
        }
        $data = array();
        if(!empty($posts))
        {
            foreach ($posts as $list)
            {
                $nestedData['id'] = $list->id;
                $nestedData['created_at'] = date('d M Y h:ia',strtotime($list->created_at));
                $nestedData['title'] =  ucfirst($list->title);
                $nestedData['slug'] =  $list->slug;
                $nestedData['action'] =  Helper::getButtons([
                                ['key'=>'Edit','link'=>route('pages.add',$list->id)],
                                ['key'=>'View','link'=>route('pages.view',$list->slug)],
                                ['key'=>'Delete','link'=>$list->id]                                
                            ]);
                $data[] = $nestedData; 
            }
        }

      $json_data = array(
                "draw"            => intval($request->input('draw')),  
                "recordsTotal"    => intval($totalData),  
                "recordsFiltered" => intval($totalFiltered), 
                "data"            => $data   
                );
        echo json_encode($json_data); 
    }    
    
    public function delete(Request $request)
    {
        $user_id = $request->user_id;
        try{
            $delete = Page::where('id','=',$user_id)->delete();   
            if($delete){
                echo json_encode(["type"=>"success","data"=>"Record Deleted"]); 
            }else{
                echo json_encode(["type"=>"error","data"=>"Could not deleted Record"]); 
            }
        }catch(\Exception $e){
            echo json_encode(["type"=>"error","data"=>$e->getMessage()]);   
        }
    }

    public function add(Request $request, $id=null){
        $title = "Add New Page";
        $breadcrumbs = [
            ['name'=>'CMS Pages','url'=>url('admin/pages'),'relation'=>'link'],
            ['name'=>'Add New Page','url'=>'','relation'=>'current'],
        ];
        $data = ($id)?Page::find($id):array();
        if($request->ajax() && $request->isMethod('post')){
            try {
                $validator = Page::validate($request->all(),$id);
                if($validator->fails()){
                    return response()->json(array('errors' => $validator->messages()), 422);
                }else{
                    $formData = $request->all();
                    if($id){                        
                        $data->update($formData);
                        Session::flash('success','Page updated successfully');
                    }else{
                        Page::create($formData);
                        Session::flash('success','Page created successfully');
                    }
                    return ['status' => true, 'message' => 'Records updated successfully'];                  
                }
            } catch (\Exception $e) {
                return ['status' => false, 'message' => $e->getMessage()];
            }            
        }
        return view('admin.pages.add',compact('data','id','title','breadcrumbs'));
    }

    public function view($slug){
        $data = Page::where('slug',$slug)->first();
        if($data){ 
            return view('admin.pages.view',compact('data'));
        }else{
            return abort('404');
        }
    }
}
