<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\Validator;
use Session; 
use App\Models\User;
use Hash;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //dd(Auth::guard()->user()->username);
        $breadcrumbs = [];
        $title = "Dashboard"; 
        return view('home',compact('breadcrumbs','title'));
    }
    
    public function forgot(Request $request)
    {
        if($request->isMethod('post')){
            try{
                $rules =['email'         => 'required|email'];
                $validator = Validator::make($request->all(), $rules);
                if ($validator->fails()){
                    Session::flash('danger', "Something went wrong. Try again");
                    //dd($validator);
                    return redirect('/forgot')->withErrors($validator);
                }else{
                    if(User::where('email','=',$request['email'])->exists()){
                        $token = $this->random(45);
                        $userDetails = User::where('email','=',$request['email'])->first();
                        $userDetails->forgot_token = $token;
                        $userDetails->save();
                        $data['templete']       = "forgot";
                        $data['name']           = $userDetails->username;
                        $data['forgot_token']   = $token;
                        $data['email']          = $userDetails->email;
                        $data['subject']        = "Forgot Password.";
                        //dd($data);
                        Email::send($data);
                    }else{
                        Session::flash('danger', 'Incorrect email.');
                        return redirect()->to('forgot');                    
                    }
                    Session::flash('success', 'Reset password link has been sent successfully to '.$request['email']);
                    return redirect()->to('forgot');                    
                }            
            }catch(\Exception $e){
                Session::flash('danger', $e->getMessage());
                return redirect()->back();                
            }
            //dd($request->all());
        }
        //dd(Auth::guard()->user()->username);
        return view('auth.forgot');
    }    
 
    public function reset(Request $request,$token=null){ 
        $title = "Change Password";
        $user = User::where('token',$token)->first();
        if($user){
            if($request->ajax() && $request->isMethod('post')){
                try {      
                    $rules = [
                        'token'    => 'required',   
                        'password' => 'required|min:8',
                        'password_confirmation' => 'required_with:password|same:password|min:8'
                    ];
                    $validator = Validator::make($request->all(), $rules);
                    if ($validator->fails()) {
                        return response()->json(array('errors' => $validator->messages()), 422);
                    }else{
                       $password = Hash::make($request->get('password'));
                       $user->update(['password'=>$password,'token'=>'']);
                        //Session::flash('success','Password chagned successfully');
                        return ['status' => true, 'message' => 'Password chagned successfully']; 
                    }
                } catch (\Exception $e) {
                    return ['status' => false, 'message' => $e->getMessage()];   
                }
            }
            return view('auth.reset',compact('data','token','title'));
        }else{
            return abort(404);
        }
    }
    
    public function verification($verification){
        $user =  User::where('token',$verification)->exists();
        if($user){
            User::where('token',$verification)->update(['token'=>'','status'=>1]);
            Session::flash('success', 'Email verification completed successfully.');
            //return redirect()->back();
        }else{
            Session::flash('danger', 'You have already verified your email address');
            //return redirect()->back();
            //return redirect('/');
        }
        return view('auth.verification');
    }

    // cron set for unVerified user
    public function checkUnVerifiedUser()
    {
        $user = User::where('verified',0)->get()->toArray();
        // dd($user);
        foreach ($user as $key => $value) {
            // $token = $this->random(45);
            // $data['templete']       = "welcome";
            // $data['name']           = $value['first_name']." ".$value['last_name'];
            // $data['token']          = $token;
            // $data['email']          = 'mahaveer90@mailinator.com';
            // $data['subject']        = "Mail from email verification Vicarious.!";
            // Email::send($data);

            $date15 = date('Y-m-d', strtotime($value['created_at']. ' + 15 days'));
            $date14 = date('Y-m-d', strtotime($value['created_at']. ' + 14 days'));

            echo $date14.' '.$value['id']; echo "<br/>";

            $today  = date('Y-m-d');
            if($today>=$date15)
            {
                $user = User::find($value['id']);
                $user->status = 0;
                $user->save();

            }elseif($today==$date14)
            {
                $data['templete']       = "welcome";
                $data['name']           = $value['first_name']." ".$value['last_name'];
                $data['token']          = $value['token'];
                $data['email']          = $value['email'];
                $data['subject']        = "Mail from email verification Vicarious.!";
                Email::send($data);

            }
        }
    }
    
}
