<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller as Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class ApiController extends Controller
{
    
    
    public function __construct(){
        $response = [];
    }
    
    function response($data){
        $data = $this->arrayHandleFun($data);
        header("Access-Control-Allow-Origin: http://localhost/vicarious/api");
        header('Access-Control-Allow-Methods: GET,HEAD,OPTIONS,POST,PUT');
        header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers, Authorization, X-CSRF-Token');
        header('Access-Control-Allow-Credentials: true');         
        echo json_encode($data); die();
    }
    
    function validationHandle($validation){
        foreach ($validation->getMessages() as $field_name => $messages){
            if(!isset($firstError)){
                $firstError        =$messages[0];
                $error[$field_name]=$messages[0];
            }
        }
        return $firstError;
    }
    
    function random($length = 30){
        $pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        return substr(str_shuffle(str_repeat($pool, $length)), 0, $length).time();
    }
    
    
    function arrayHandleFun($array, $isRepeat = false){        
        foreach ($array as $key => $value) {
            if ($value === null) { 
                $array[$key] =  "";
            }else if (is_array($value)) {
                if (empty($value)){
                    //$array[$key] = "";
                }else{
                    $array[$key] = SELF::arrayHandleFun($value);
                } 
            }
        }
        if (!$isRepeat) {
            $array = SELF::arrayHandleFun($array,true);
        }
        return $array;        
    }    
    
    
    
}
