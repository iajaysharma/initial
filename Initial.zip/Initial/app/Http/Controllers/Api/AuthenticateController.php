<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\ApiController;
use Illuminate\Http\Request;
use Validator;
use JWTAuth;
use JWTAuthException;
use App\Models\User;
//use Illuminate\Support\Facades\Auth;

class AuthenticateController extends ApiController
{
	
    public function authorizeToken(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email|max:255',
            'password'=> 'required'
        ]);
        if ($validator->fails()) {
            return response()->json($validator->errors());
        }
        $credentials = $request->only('email', 'password');
        try {
            if (! $token = JWTAuth::attempt($credentials)) {
                return response()->json(['status'=>'false','error' => 'invalid_credentials'], 401);
            }
        } catch (JWTException $e) {
            return response()->json(['status'=>'false','error' => 'could_not_create_token'], 500);
        }
        return response()->json(['status'=>'true','token'=>$token]);
    }
	
	
}
