<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\ApiController;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Mail;

use Session;
use App\Lib\Uploader;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;

use Illuminate\Validation\Rule;
use App\Lib\PushNotification;
use DB;
// Load Models
use App\Models\User;
use App\Models\Page;
use App\Models\UserDevices;
use App\Models\Country;
use App\Models\Setting;
use App\Models\Template;
use Event;
use App\Events\SendMail;
class UserController extends ApiController{


    public function __construct(){
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    // This method use for default request handle
    public function index(Request $request){

    }
    
    // This method use for signup
    protected function signup(Request $request){
        
        $data = $request->all();
        $validator = Validator::make($request->all(), [
            'name'    	        => 'required|max:45',
            'email'             => 'required|unique:users|email',
            'username'         	=> 'nullable|min:8|max:45|unique:users',
            'dob'               => 'date_format:"Y-m-d"|required',
            'country_id'        => 'required|numeric',
            'password'      	=> 'required|min:8|max:45', 
            'device_type'   	=> 'required',
            'device_token'  	=> 'required',
            'user_type'         => 'required',    
            'profile_picture'   => 'nullable|image',
            'mobile'            => 'nullable|numeric',    
            'address'           => 'nullable|max:255'    
        ]);

        if ($validator->fails()){
            $response['status'] = "false"; 
            $response['message'] = $this->validationHandle($validator->messages()); 
            $response['data'] = [];
        }else{
            try{
                $token = $this->random(45).time();
                $formData = $request->except('password');
                $formData['password'] = Hash::make($request->get('password'));
                $formData['token'] = $token;
                $formData['status'] = ($request['user_type']=="App")?2:1; 
                $user = User::create($formData);  
                if($request->file('profile_picture')!==null){
                    // This code use for profile picture upload
                    $destinationPath = '/uploads/profile/'.$user->id.'/';
                    $responseData = Uploader::doUpload($request->file('profile_picture'),$destinationPath,true);    
                    if($responseData['status']=="true"){
                        $userr = User::find($user->id);
                        $userr->profile_picture = $responseData['file'];
                        $userr->save();                    
                    }                             
                } 
                $user = User::getProfile($user->id);
                if($user['email']!=""){
                    $mail['type'] = 'VERIFY_EMAIL';
                    $mail['user_id'] = $user['id'];
                    Event::fire(new SendMail($mail));
                }
                if($user){
                    UserDevices::deviceHandle([
                        "id"       =>  $user['id'],
                        "device_type"   =>  $data['device_type'],
                        "device_token"  =>  $data['device_token'],
                    ]);
                }                
                $jwtResponse = User::authorizeToken($request);   
                $response['data'] = $user; 
                if($request['user_type']!="App"){
                    $response['security_token'] = @$jwtResponse['token']; 
                    $response['message'] = "User has been registered successfully."; 
                }else{
                    $response['security_token'] = null; 
                    $response['message'] = "User has been registered successfully, Please verify your email address."; 
                }
                $response['status'] = "true"; 
            } catch (\Exception $e) {
                $response['status'] = "false";
                $response['message'] = $e->getMessage();
                $response['data'] = [];
            }                    
        }                 
        $this->response($response);
        
    }
    
    // This method use for signup
    protected function otp(Request $request){        
        $data = $request->all();
        $validator = Validator::make($request->all(), [
            'first_name'    	=> 'required',
            'last_name'     	=> 'required',
            'email'         	=> 'required|unique:users',
            'mobile'         =>  ["required","numeric","min:7",Rule::unique('users')->where(function ($query)use ($request) { return $query->where('country_id',"=", $request->country_id); })],
            'country_id'        => 'required|numeric',
            'password'      	=> 'required|min:8|max:15',
            'account_type'      => 'required',
            'device_type'   	=> 'required',
            'device_token'  	=> 'required',
        ]);

        if ($validator->fails()){
            $response['status'] = "false"; 
            $response['message'] = $this->validationHandle($validator->messages()); 
            $response['data'] = []; 
            $this->response($response);
        }else{
                if ($validator->fails()){
                    $response['status'] = "false"; 
                    $response['message'] = $this->validationHandle($validator->messages()); 
                    $response['data'] = []; 
                }else{
                    try{
                        $opt = substr(str_shuffle("0123456789"), 0, 4);
                        $response['otp'] = $opt; 
                        $response['status'] = "true"; 
                        $response['message'] = "Otp for verify."; 
                    } catch (\Exception $e) {
                        $response['status'] = "false";
                        $response['message'] = $e->getMessage();
                        $response['otp'] = "";
                    }                    
                }                 
            $this->response($response);
        }
        
    }    
    
    
    // This method use for checkUser
    protected function checkUser(Request $request){
        
        $data = $request->all();
        $validator = Validator::make($request->all(), [
            'social_id'    	    => 'required',
            'device_type'   	=> 'required',
            'device_token'  	=> 'required',
        ]);              
        if ($validator->fails()){
            $response['status']         = "false";  
            $response['message'] = $this->validationHandle($validator->messages()); 
            $response['data'] = []; 
            $this->response($response);
        }else{
            if ($validator->fails()){
                $response['status']         = "false";  
                $response['message'] = $this->validationHandle($validator->messages()); 
                $response['data'] = []; 
            }else{
                try{
                    if(User::where('email','=',$request['email'])->exists() || User::where('social_id','=',$request['social_id'])->exists()){
                        if(isset($request['email']) && !empty($request['email'])){
                            User::where('email','=',$request['email'])->update(['social_id'=>$request['social_id']]);
                            $user = User::where('email','=',$request['email'])->first();
                        }else{
                            $user = User::where('social_id','=',$request['social_id'])->first();
                        }

                        UserDevices::deviceHandle([
                            "id"       =>  $user->id,
                            "device_type"   =>  $data['device_type'],
                            "device_token"  =>  $data['device_token'],
                        ]);

                        $jwtResponse = User::authorizeUserToken($user);                        
                        $response['data'] = User::getProfile($user->id); 
                        $response['status']         = "true";  
                        $response['message'] = "User details.";
                        $response['security_token'] = @$jwtResponse['token'];
                    }else{
                        $response['data'] = []; 
                        $response['status']         = "false";  
                        $response['message'] = "User not exists."; 
                    }
                } catch (\Exception $e) {
                    $response['status']         = "false"; 
                    $response['message'] = $e->getMessage();
                    $response['otp'] = "";
                }                    
            }                 
            $this->response($response);
        }
        
    }
    
    // This method use for signin
    protected function signin(Request $request){
        
        $data = $request->all();
        $rules =[
                    'email'         => 'required|email',
                    'password'      => 'required',
                    'device_type'   => 'required',
                    'device_token'  => 'required',
                ];
        $validator = Validator::make($data, $rules);
        if ($validator->fails()) {
            $response['status'] = "false"; 
            $response['message'] = $this->validationHandle($validator->messages()); 
            $response['data'] = []; 
            $this->response($response);
        } else {            
                $userdata = ['email'     => $data['email']];
                try{
                $user = \DB::table("users")->where($userdata)->first();
                if(!$user){
                    $response['status'] = "false"; 
                    $response['message'] = "Email not exist."; 
                    $response['data'] = []; 
                    $this->response($response);
                }else{
                    if(Hash::check($data['password'],$user->password)){
                        if($user->status==2){
                            $response['status'] = "false"; 
                            $response['message'] = "Your email is not verified."; 
                            $response['data'] = []; 
                            $this->response($response);
                        }else if ($user->status==0){
                            $response['status'] = "false"; 
                            $response['message'] = "Your account is inactivated contact to administrator."; 
                            $response['data'] = []; 
                            $this->response($response);
                        }else{
                            $jwtResponse = User::authorizeToken($request);  
                            UserDevices::deviceHandle([
                                "id"       =>  $user->id,
                                "device_type"   =>  $data['device_type'],
                                "device_token"  =>  $data['device_token'],
                            ]);
                            $response['status'] = "true"; 
                            $response['message'] = "User signin sucessfully."; 
                            $response['data'] = User::getProfile($user->id); 
                            $response['security_token'] = @$jwtResponse['token']; 
                            $this->response($response);
                        }
                    }else{
                        $response['status'] = "false"; 
                        $response['message'] = "Password Incorrect!."; 
                        $response['data'] = []; 
                        $this->response($response);
                    }
                }
            }catch (\Exception $e) {
                $response['status'] = "false";
                $response['message'] = $e->getMessage();
                $response['data'] = [];    
                $this->response($response);            
            }

        }   
        
    }
    
    // This method use for get profile
    public function getProfile(Request $request){
        if($request->isMethod('post')){
            try{
                $userId = JWTAuth::toUser(JWTAuth::getToken())->id;
                $profile = User::getProfile($userId);
                $response['status'] = (count($profile)>0)?"true":"false"; 
                $response['message'] = "User profile data."; 
                $response['data'] = $profile; 
            } catch (\Exception $e) {
                $response['status'] = "false";
                $response['message'] = $e->getMessage();
                $response['data'] = [];                
            }
            $this->response($response);
        }
    }   
    
    // This method use for update profile
    public function updateProfile(Request $request){        
        $data = $request->all();
        $userId = JWTAuth::toUser(JWTAuth::getToken())->id;

        $validator = Validator::make($request->all(), [
            'name'      => 'required|max:45',  
            'email'     => 'required|unique:users,email,'.$userId,
            'username'  => 'min:8|max:45|required|unique:users,username,'.$userId,
            'dob'       => 'date_format:"Y-m-d"|required',
            'country_id'=> 'required|numeric',
            'profile_picture'   => 'nullable|image',
            'mobile'            => 'nullable|numeric',    
            'address'           => 'nullable|max:255'
        ]);

        if ($validator->fails()){
            $response['status'] = "false"; 
            $response['message'] = $this->validationHandle($validator->messages());  
            $response['data'] = []; 
            $this->response($response);
            
        }else{
			try{
                $user = User::find($userId);
                $user->name = $data['name'];
                $user->username = $data['username'];
                $user->email = $data['email'];
                $user->dob = $data['dob'];
                $user->country_id = $data['country_id'];
                if($user->save()){                    
                    if($request->file('profile_picture')!==null){
                        // This code use for profile picture upload
                        $destinationPath = 'uploads/profile/'.$user->id.'/';
                        $responseData = Uploader::doUpload($request->file('profile_picture'),$destinationPath,true);    
                        if($responseData['status']=="true"){
                            $user = User::find($user->id);
                            $user->profile_picture = $responseData['file'];
                            $user->save();                    
                        }                             
                    }
                    $response['status'] = "true"; 
                    $response['message'] = "Profile updated successfully."; 
                    $response['data'] = User::getProfile($user->id); 
                    $this->response($response);
                }
            }catch (\Exception $e) {
                $response['status'] = "false";
                $response['message'] = $e->getMessage();
                $response['data'] = [];  
                $this->response($response);              
            }   
        }
    }
    
    // This method use for change password
    public function changePassword(Request $request){
        $data = $request->all();
        $validator = Validator::make($request->all(), [
            'current_password'          => 'required|min:8|max:45',
            'new_password'           => 'required|min:8|max:45',
        ]);
        if ($validator->fails()){
            $response['status'] = "false"; 
            $response['message'] = $this->validationHandle($validator->messages());  
            $this->response($response);
        }else{
            $userId = JWTAuth::toUser(JWTAuth::getToken())->id;
            $userdata = ['id'     => $userId];
            // attempt to do the login
            $user = \DB::table("users")->where($userdata)->first();
            if(!$user){
                $response['status'] = "false"; 
                $response['message'] = "User id not exist."; 
                $this->response($response);
            }else{
                if(Hash::check($data['current_password'],$user->password)){
                    $user = User::find($userId);
                    $user->password = bcrypt($data['new_password']);
                    $user->save();
                    $response['status'] = "true"; 
                    $response['message'] = "Password reset successfully."; 
                    $this->response($response);
                }else{
                    $response['status'] = "false"; 
                    $response['message'] = "Current Password doesn't match."; 
                    $this->response($response);
                }
            }
        }
    }
    
    // This method use for forgot password
    public function forgot(Request $request){
        $data = $request->all(); 
        $validator = Validator::make($request->all(), ['email' => 'required|email']);
        if($validator->fails()){
            $response['status']     = "false"; 
            $response['message']    = $this->validationHandle($validator->messages());  
            $this->response($response);
        }else{
            try{
                $userdata = ['email'=> $data['email']];
                // attempt to do the login
                $user = \DB::table("users")->where($userdata)->first();
                if(!$user){
                    $response['status']     = "false"; 
                    $response['message']    = "Email not exist."; 
                    $this->response($response);
                }else{
                    $mail['type'] = 'FORGOT_PASSWORD';
                    $mail['user_id'] = $user->id;
                    Event::fire(new SendMail($mail));                    
                    $response['status'] = "true"; 
                    $response['message'] = "Reset password link has been sent successfully to your email address.";
                    $this->response($response);
                }
            }catch (\Exception $e) {
                $response['status'] = "false";
                $response['message'] = $e->getMessage();
                $response['data'] = [];  
                $this->response($response);              
            }   
        }
    }
    
    // This method use for logout user.
    public function logout(Request $request){
        $validator = Validator::make($request->all(), [
            'device_type'       => 'required',
            'device_token'      => 'required',
        ]);

        if ($validator->fails()){
            $response['status'] = "false"; 
            $response['message'] = $this->validationHandle($validator->messages()); 
            $this->response($response);
        }else{   
            try{
                $userDevice = UserDevices::where(['device_type'=> $request['device_type'],'device_token'=>$request['device_token']])->first();
                $token = JWTAuth::getToken();
                if ($token) {
                    JWTAuth::setToken($token)->invalidate();
                }            
                if($userDevice){
                    UserDevices::where(['device_type'=> $request['device_type'],'device_token'=>$request['device_token']])->delete();
                    $response['status'] = "true"; 
                    $response['message'] = "Logout sucessfully."; 
                    $this->response($response);            
                }else{
                    $response['status'] = "true"; 
                    $response['message'] = "Logout sucessfully."; 
                    $this->response($response);            
                }
            }catch (\Exception $e) {
                $response['status'] = "false";
                $response['message'] = $e->getMessage();
                $response['data'] = [];  
                $this->response($response);                 
            }             
        }     
    }
 
    // list of country
    public function getCountry(){
        try{
            $countries = []; 
            $countries = Country::all()->toArray();
            foreach($countries as $key => $country){
                //$id = '"'.$country->id.'"';
                //echo $id; die;
                //$countries[$key]->id = "";
                $countries[$key]['id']  = (string) $country['id'];
                $countries[$key]['phonecode']  = (string) "+".$country['phonecode'];
            }
            $response['status'] = "true"; 
            $response['message'] = "Country List Data."; 
            $response['data'] = $countries; 
            $this->response($response);               
        }catch(\Exception $e){
            $response['status'] = "false"; 
            $response['message'] = $e->getMessage(); 
            $response['data'] = []; 
            $this->response($response);        
        }
    }
}
