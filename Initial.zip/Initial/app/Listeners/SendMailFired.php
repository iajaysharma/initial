<?php

namespace App\Listeners;

use App\Events\SendMail;

use Illuminate\Queue\InteractsWithQueue;

use Illuminate\Contracts\Queue\ShouldQueue;

use App\Models\User;

use Mail;
use App\Models\Setting;
use App\Models\Template;
class SendMailFired

{

    public function __construct()
    {

        
    }

    public function handle(SendMail $data)

    {
        $data = $data->data;
        switch ($data['type']) {
            // User email verification
            case 'VERIFY_EMAIL':
                $user_data = User::find($data['user_id']);
                $email = $user_data->email;
                $token = str_random(40);
                $user_data->update(['token'=>$token]);
                $mail_data = Template::where('slug', '=', 'user-email-verification')->first();
                $site_setting = Setting::pluck('value','field_name');
                if($mail_data){  
                    $site_email      = $site_setting['site_email'];
                    $site_title      = $site_setting['site_title'];
                    $link = '<a class="btn-mail" href="'.route('users.verification',$token).'">Click for verify Email</a>';
                    if($mail_data and $email){
                        $message        =   str_replace(array('{NAME}', '{LINK}', '{SITE_TITLE}'), array($user_data->name, $link, $site_title), $mail_data->content);
                        $subject        = $mail_data->title;
                        
                        Mail::send('email.email', array('data'=>$message), function($message) use ($site_email, $email, $subject, $site_title){ 
                            $message->from($site_email, $site_title);
                            $message->to($email, $email)->subject($subject);
                        });
                        return ['status' => true, 'message' => "Verification email has been sent."];
                    }else{
                        return ['status' => false, 'message' => "Error while sending email, please try again"];
                    }                    
                }else{
                    return ['status' => false, 'message' => "Email template not found"];
                }
                break;

            // user forggot password email   
            case 'FORGOT_PASSWORD':
                $user_data = User::find($data['user_id']);
                $email = $user_data->email;
                $token = str_random(40);
                $user_data->update(['token'=>$token]);
                $mail_data = Template::where('slug', '=', 'user-forgot-password')->first();
                $site_setting = Setting::pluck('value','field_name');
                if($mail_data){  
                    $site_email      = $site_setting['site_email'];
                    $site_title      = $site_setting['site_title'];
                    $link = '<a class="btn-mail" href="'.route('users.reset',$token).'">Click for Reset Password</a>';
                    if($mail_data and $email){
                        $message        =   str_replace(array('{NAME}', '{LINK}', '{SITE_TITLE}'), array($user_data->name, $link, $site_title), $mail_data->content);
                        $subject        = $mail_data->title;
                        
                        Mail::send('email.email', array('data'=>$message), function($message) use ($site_email, $email, $subject, $site_title){ 
                            $message->from($site_email, $site_title);
                            $message->to($email, $email)->subject($subject);
                        });
                        return ['status' => true, 'message' => "Reset password link has been sent successfully to your email address."];
                    }else{
                        return ['status' => false, 'message' => "Error while sending email, please try again"];
                    }                    
                }else{
                    return ['status' => false, 'message' => "Email template not found"];
                }
                break;    

            default:
                # code...
                break;
        }

    }

}