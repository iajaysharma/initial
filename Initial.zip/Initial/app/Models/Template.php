<?php

namespace App\Models;

use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Validator;
class Template extends Authenticatable
{ 
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'title','slug','content','keys'
    ];

    public static function validate($input,$id){
        $rules = [
            'title'     =>      'required|max:100',
            'slug'      =>      'required|max:100|unique:templates,slug,'.$id,
            'content'   =>      'required',
            'keys'      =>      'required'
        ];

        $messages = [
            'title.required'     =>      'Title is required',
            'slug.required'      =>      'Slug is required',
            'slug.unique'        =>      'Slug has already been taken',
            'content.required'   =>      'Content is required',
            'keys.required'      =>      'Keys is required'      
        ];

        return validator::make($input,$rules,$messages);
    }
}
