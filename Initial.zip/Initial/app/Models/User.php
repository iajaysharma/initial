<?php

namespace App\Models;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password','country_id','profile_picture','mobile','dob','gender','user_type','social_type','address','social_id','token','status','username'
    ];

    public static function getProfile($id){
        return User::where('id','=',$id)->with(['country'])->first()->toArray();
    }

    public static function authorizeToken($request)
    {
        $credentials = $request->only('email', 'password');
        try {
            //DD(JWTAuth::attempt($credentials));
            if (! $token = JWTAuth::attempt($credentials)) {
                return ['status'=>'false','error' => 'invalid_credentials','code'=>401];
            }
        } catch (JWTException $e) {
            return ['status'=>'false','error' => 'could_not_create_token','code'=>500];
        }
        return ['status'=>'true','token'=>$token,'code'=>200];
    }

    public static function authorizeUserToken($request)
    {
        $token = JWTAuth::fromUser($request);
        try {
            if (!$token) {
                return ['status'=>'false','error' => 'invalid_credentials','code'=>401];
            }
        } catch (JWTException $e) {
            return ['status'=>'false','error' => 'could_not_create_token','code'=>500];
        }
        return ['status'=>'true','token'=>$token,'code'=>200];
    }
    

    public function country(){
       return $this->belongsTo('App\Models\Country','country_id');
    }

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
}
