<?php

namespace App\Models;

use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Validator;
class Page extends Authenticatable
{ 
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'cms_pages';
    protected $fillable = [
        'title','slug','content','meta_title','meta_content'
    ];

    public static function validate($input,$id){
        $rules = [
            'title'         =>      'required|max:100',
            'slug'          =>      'required|max:100|unique:cms_pages,slug,'.$id,
            'content'       =>      'required',
            'meta_title'    =>      'max:255'
        ];

        $messages = [
            'title.required'     =>      'Title is required',
            'slug.required'      =>      'Slug is required',
            'slug.unique'        =>      'Slug has already been taken',
            'content.required'   =>      'Content is required'
        ];

        return validator::make($input,$rules,$messages);
    }
}
