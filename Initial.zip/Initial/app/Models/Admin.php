<?php

namespace App\Models;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Validator;
class Admin extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['email', 'password','profile_image','name','token','country_id'];
    
    protected $table = "admin";

    public $timestamp = false;
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ]; 

     public function country(){
       return $this->belongsTo('App\Models\Country','country_id');
    }

    public static function validate($input,$id){
        $rules = [ 
            'email'         =>      'required|email|unique:admin,email,'.$id,  
            'profile_image' =>      'nullable|image',
            'name'          =>      'required'
        ];
        $validator =  Validator::make($input, $rules);
        return $validator;
    }
    
}
