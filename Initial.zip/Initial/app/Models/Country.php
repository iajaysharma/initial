<?php

namespace App\Models;

use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;

class Country extends Model
{


    protected $fillable = [
        'name', 'email', 'password',
    ];
    
    protected $table = "countries";

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
}
