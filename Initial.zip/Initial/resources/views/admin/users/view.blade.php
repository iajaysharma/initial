@extends('admin.layouts.default')
@section('content')
<!-- Start Page Content -->
<div class="row">
	<div class="col-lg-12">
		<div class="ui raised segment">
			<div class="avatar text-center">
				@if($data->profile_picture && file_exists($data->profile_picture))
				<img alt="{{$data->name}}" style="margin:0 auto;max-height: 75px;" src="{{url($data->profile_picture)}}">
				@else
				<img class="media-object img-thumbnail user-img" style="margin:0 auto;" alt="User Picture" src="{{url('public/admin/assets/img/user.gif')}}"> 
				@endif
			</div>
			<h3 class="text-center" style="margin-top: 5px;">{{$data->name}}</h3><hr>
			<div style="text-align:center">
				<div class="row">
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Name</strong>
						<br>
						<p class="text-muted">{{$data->name}}</p>
					</div>
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Email</strong>
						<br>
						<p class="text-muted">{{$data->email}}</p>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Country</strong>
						<br>
						<p class="text-muted">{{isset($data->country->name)?$data->country->name:'---'}}</p>
					</div>
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Mobile</strong>
						<br>
						<p class="text-muted">{{($data->mobile)?$data->mobile:'---'}}</p>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Gender</strong>
						<br>
						<p class="text-muted">{{($data->gender)?$data->gender:'---'}}</p>
					</div>
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Date of Birth</strong>
						<br>
						<p class="text-muted">{{($data->dob)?date("d M Y",strtotime($data->dob)):'---'}}</p>
					</div>
				</div> 
				<div class="row">
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Username</strong>
						<br>
						<p class="text-muted">{{($data->username)?$data->username:'---'}}</p>
					</div>
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Address</strong>
						<br>
						<p class="text-muted">{{($data->address)?$data->address:'---'}}</p>
					</div>
				</div> 
				<div class="row">
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Status</strong>
						<br>
						@if($data->status==1)
						<span class="btn btn-success btn-sm">Active</span>
						@elseif($data->status==0)
						<span class="btn btn-danger btn-sm">InActive</span>
						@elseif($data->status==2)
						<span class="btn btn-danger btn-sm">UnVerified</span>
						@else
						<span class="btn btn-success btn-sm">N/A</span>
						@endif
					</div>
					<div class="col-md-6 col-xs-6 b-r m-b-15"> <strong>Created At</strong>
						<br>
						<p class="text-muted">{{($data->created_at)?date("d M Y",strtotime($data->created_at)):'---'}}</p>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<a class="btn btn-success" href="javascript:history.back()">Go Back</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- End PAge Content -->
@stop