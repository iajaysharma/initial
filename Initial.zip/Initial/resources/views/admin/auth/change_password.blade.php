@extends('admin.layouts.default-auth')
@section('content')
<div class="form-signin ">    
    <div class="tab-content ui segment">
        <div id="login" class="tab-pane active">
            <form id="admin-update-password" class="ui form">
                <p class="text-muted text-center">
                    {{$title}}
                </p>                
                <input type="hidden" name="_token" value="{{ csrf_token() }}" />
                <input type="hidden" name="token" value={{$token}}>
                <input type="password" placeholder="Password" name="password" class="form-control top">
                <span class="error password"></span>
                <br>
                <input type="password" style="margin-bottom: 0px;" name="password_confirmation" placeholder="Confirm Password" class="form-control bottom">
                <span class="error password_confirmation"></span> 
                <br>                 
                <button class="ui button primary btn-block submit-btn" type="submit">Change Password</button>
            </form>
        </div>
    </div>
</div>
@stop
@section('scripts')
<script>
    $("#admin-update-password").on('submit', (function (e) {
    e.preventDefault();
    $(".segment").addClass('loading');
    $(".error").html("");
    $.ajax({
        url: baseUrl+'/admin/change-password/{!! $token !!}',
        type: "POST",
        data: new FormData(this),
        contentType: false,
        cache: false,
        processData: false,
        success: function (data) { 
            $(".segment").removeClass('loading');
            if(data.status==true){                  
                window.location.href = baseUrl+'/admin';
            }else{
                swal("Ohh!!No",data.message,"error");
            }
        },
        error: function (data) {
            $(".segment").removeClass('loading');
            var response = JSON.parse(data.responseText); 
            $.each(response.errors, function (k, v) {
                $("." + k).html(v);
            }); 
        }
    });        

}));
</script>
@stop