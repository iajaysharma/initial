@extends('admin.layouts.default-auth')
@section('content')
<div class="form-signin ">    
    <div class="tab-content ui segment">
        <div id="login" class="tab-pane active">
            <form id="loginForm" class="ui form">
                <p class="text-muted text-center">
                    Enter your email and password
                </p>
                <div class="alert alert-danger alert-box" style="display: none;"></div>
                <input type="hidden" name="_token" value="{{ csrf_token() }}" />
                <input type="email" placeholder="Email" name="email" class="form-control top">
                <span class="error email"></span>
                <br>
                <input type="password" style="margin-bottom: 0px;" name="password" placeholder="Password" class="form-control bottom">
                <span class="error password"></span>
                <div class="checkbox">
                    <label>
                        <input type="checkbox" name="remember"> Remember Me
                    </label>
                </div>
                <button class="ui button primary btn-block submit-btn" type="submit">Sign in</button>
            </form>
        </div>
        <div id="forgot" class="tab-pane">
            <form action="" class="ui form" id="admin-reset-form">
                <p class="text-muted text-center">Enter your valid e-mail</p>
                <input type="hidden" name="_token" value="{{ csrf_token() }}" />
                <input type="email" name="email" placeholder="mail@domain.com" class="form-control">
                <span class="error email"></span>
                <br>
                <button class="ui button primary btn-block" type="submit">Recover Password</button>
            </form>
        </div> 
    </div>
    <hr>
    <div class="text-center">
        <ul class="list-inline">
            <li><a class="text-muted" href="#login" data-toggle="tab">Login</a></li>
            <li><a class="text-muted" href="#forgot" data-toggle="tab">Forgot Password</a></li> 
        </ul>
    </div>
</div>
@stop