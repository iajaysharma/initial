<footer class="Footer bg-dark dker">
	@if(isset($site_settings['website_copyright']))
	<p>{{$site_settings['website_copyright']}}</p>
	@else
	<p>{{date('Y')}} &copy; All Right Reserve.</p>
	@endif
</footer>