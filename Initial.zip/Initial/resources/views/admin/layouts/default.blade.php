<!doctype html>
<html>

<head>
    <meta charset="UTF-8">
    <!--IE Compatibility modes-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--Mobile first-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Admin {{(isset($title))?$title:''}}</title>
    
    <meta name="description" content="">
    <meta name="author" content="">
    
    <meta name="msapplication-TileColor" content="#5bc0de" />
    <meta name="msapplication-TileImage" content="{{url('public/admin/assets/img/metis-tile.png')}}" />
    
    <!-- Bootstrap -->
    <link rel="stylesheet" href="{{url('public/admin/assets/lib/bootstrap/css/bootstrap.css')}}">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="{{url('public/admin/assets/font-awesome/css/font-awesome.min.css')}}">
    
    <!-- Metis core stylesheet -->
    <link rel="stylesheet" href="{{url('public/admin/assets/css/main.css')}}">
    <link rel="stylesheet" href="{{url('public/admin/assets/css/theme.css')}}">
    <link rel="stylesheet" href="{{url('public/admin/css/helper.css')}}">
    
    <!-- metisMenu stylesheet -->
    <link rel="stylesheet" href="{{url('public/admin/assets/lib/metismenu/metisMenu.css')}}">
    
    <!-- onoffcanvas stylesheet -->
    <link rel="stylesheet" href="{{url('public/admin/assets/lib/onoffcanvas/onoffcanvas.css')}}">
    <link rel="stylesheet" href="{{url('public/admin/css/semantic.min.css')}}">
    <link rel="stylesheet" href="{{url('public/admin/assets/UI-Icon-master/icon.min.css')}}">
    <link rel="stylesheet" href="{{url('public/admin/assets/lib/summernote/summernote.css')}}">    
    <!-- animate.css stylesheet -->
    <link rel="stylesheet" href="{{url('public/admin/css/custom.css')}}">



<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
    @yield('styles') 
    
  </head>

        <body class="  ">
            <div class="bg-dark dk" id="wrap">                
                @include('admin.layouts.header')
                @include('admin.layouts.sidebar_left')
                <div id="content">
                    <div class="outer">
                        <div class="inner bg-light lter"> 
                            @include('admin.layouts.flash')
                            @yield('content') 
                        </div>
                        <!-- /.inner -->
                    </div>
                    <!-- /.outer -->
                </div>
                <!-- /#content -->                   
            </div>
            <!-- /#wrap -->
            @include('admin.layouts.footer')
            <!-- /#footer --> 
            <!--jQuery -->
            <script src="{{url('public/admin/assets/lib/jquery/jquery.js')}}"></script> 
            <!--Bootstrap -->
            <script src="{{url('public/admin/assets/lib/bootstrap/js/bootstrap.js')}}"></script>
            <!-- MetisMenu -->
            <script src="{{url('public/admin/assets/lib/metismenu/metisMenu.js')}}"></script>
            <!-- onoffcanvas -->
            <script src="{{url('public/admin/assets/lib/onoffcanvas/onoffcanvas.js')}}"></script>
            <!-- Screenfull -->
            <script src="{{url('public/admin/assets/lib/screenfull/screenfull.js')}}"></script>


            <!-- Metis core scripts -->
            <script src="{{url('public/admin/assets/js/core.js')}}"></script>
            <!-- Metis demo scripts -->
            <script src="{{url('public/admin/assets/js/app.js')}}"></script>
            <script src="{{url('public/admin/assets/lib/summernote/summernote.min.js')}}"></script>
            {{-- <script src="{{url('public/admin/js/semantic.min.js')}}"></script> --}}
            <script src="{{url('public/admin/js/sweetalert.min.js')}}"></script>            
            <script src="{{url('public/admin/assets/lib/datatables/jquery.dataTables.min.js')}}"></script>
            <script src="{{url('public/admin/assets/lib/datatables/dataTables.bootstrap.min.js')}}"></script>
            <script src="{{url('public/admin/assets/lib/datatables/jquery.tablesorter.min.js')}}"></script>
            <script src="{{url('public/admin/assets/lib/datatables/jquery.ui.touch-punch.min.js')}}"></script>            
            <script src="{{url('public/admin/js/custum.js')}}"></script>
            @yield('scripts')
        </body>

</html>
