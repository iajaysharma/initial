<div class="flash-message">
@if(session()->has('success') or session()->has('warning') or session()->has('info') or session()->has('danger'))
<div class="flash-message" onClick= "this.remove();">
    @foreach (['danger', 'warning', 'success', 'info'] as $msg)
        @if(session()->has($msg))
                <p class="alert absolte_alert  alert-{{ $msg }}">{{ session()->get($msg)}} <a href="javascript:void(0)" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>

        @endif
    @endforeach
</div> <!-- end .flash-message -->
@endif

</div>