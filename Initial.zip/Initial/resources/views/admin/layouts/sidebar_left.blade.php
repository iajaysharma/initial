<?php
$currentAction = \Route::currentRouteAction();
list($controller, $action) = explode('@', $currentAction);
$controller = preg_replace('/.*\\\/', '', $controller);
?>
<div id="left">
    {{-- <div class="media user-media bg-dark dker">
        <div class="user-media-toggleHover">
            <span class="fa fa-user"></span>
        </div>
        <div class="user-wrapper bg-dark">
            <a class="user-link" href="">
                @if(Auth::guard('admin')->user()->profile_image)
                 <img class="media-object img-thumbnail user-img" alt="User Picture" src="{{url(Auth::guard('admin')->user()->profile_image)}}"> 
                @else
                <img class="media-object img-thumbnail user-img" alt="User Picture" src="{{url('public/admin/assets/img/user.gif')}}"> 
                @endif
            </a>
            
            <div class="media-body">
                <h5 class="media-heading">&nbsp;</h5>
                <ul class="list-unstyled user-info">
                    <li><a href="{{route('admin.profile')}}"><i class="fa fa-user"></i>&nbsp;{{Auth::guard('admin')->user()->name}}</a></li>
                    <li><a href="{{route('admin.logout')}}"><i class="fa fa-lock"></i>&nbsp;Logout</a></li>
                     
                </ul>
            </div>
        </div>
    </div> --}}
    <!-- #menu -->
    <ul id="menu" class="bg-blue dker"> 
        <li class="nav-divider"></li>
        <?php $active = ($controller=="AdminController" && $action=="dashboard" )?"active":""; ?>
        <li class="{{$active}}">            
            <a href="{{route('admin.dashboard')}}">
                <i class="fa fa-dashboard"></i><span class="link-title">&nbsp;Dashboard</span>
            </a>
        </li>
        <?php 
            $active = ($controller=="UserController" && in_array($action,['index','view']) )?"active":"";
        ?> 
        <li class="{{$active}}">
            <a href="javascript:;"><i class="fa fa-users"></i>
                <span class="link-title">Users</span>
                <span class="fa arrow"></span>
            </a>
            <ul aria-expanded="false" class="collapse">  
                <?php $active = ($controller=="UserController" && $action=="index" )?"active-link":""; ?> 
                <li class="{{$active}}"><a class="{{$active}}" href="{{route('users.index')}}"><i class="fa fa-angle-right"></i>&nbsp; View All </a></li>
            </ul>
        </li>
        <?php 
            $active = ($controller=="TemplateController" && in_array($action,['index','view','add']) )?"active":"";
        ?> 
        <li class="{{$active}}">
            <a href="javascript:;"><i class="fa fa-envelope"></i>
                <span class="link-title">Email Template</span>
                <span class="fa arrow"></span>
            </a>
            <ul aria-expanded="false" class="collapse">  
                <?php $active = ($controller=="TemplateController" && $action=="index" )?"active-link":""; ?> 
                <li class="{{$active}}"><a class="{{$active}}" href="{{route('templates.index')}}"><i class="fa fa-angle-right"></i>&nbsp; View All </a></li>
                <?php $active = ($controller=="TemplateController" && $action=="add" )?"active-link":""; ?> 
                <li class="{{$active}}"><a class="{{$active}}" href="{{route('templates.add')}}"><i class="fa fa-angle-right"></i>&nbsp; Add New </a></li>
            </ul>
        </li>
        <?php 
            $active = ($controller=="PageController" && in_array($action,['index','add']) )?"active":"";
        ?> 
        <li class="{{$active}}">
            <a href="javascript:;"><i class="fa fa-file-text"></i>
                <span class="link-title">CMS Pages</span>
                <span class="fa arrow"></span>
            </a>
            <ul aria-expanded="false" class="collapse">  
                <?php $active = ($controller=="PageController" && $action=="index" )?"active-link":""; ?> 
                <li class="{{$active}}"><a class="{{$active}}" href="{{route('pages.index')}}"><i class="fa fa-angle-right"></i>&nbsp; View All </a></li>
                <?php $active = ($controller=="PageController" && $action=="add" )?"active-link":""; ?> 
                <li class="{{$active}}"><a class="{{$active}}" href="{{route('pages.add')}}"><i class="fa fa-angle-right"></i>&nbsp; Add New </a></li>
            </ul>
        </li>
        <?php 
            $active = ($controller=="SettingController" && in_array($action,['index','add']) )?"active":"";
        ?> 
        <li class="{{$active}}">
            <a href="javascript:;"><i class="fa fa-cog"></i>
                <span class="link-title">Site Settings</span>
                <span class="fa arrow"></span>
            </a>
            <ul aria-expanded="false" class="collapse">  
                <?php $active = ($controller=="SettingController" && $action=="index" )?"active-link":""; ?> 
                <li class="{{$active}}"><a class="{{$active}}" href="{{route('settings.index')}}"><i class="fa fa-angle-right"></i>&nbsp; View All </a></li>
                <?php $active = ($controller=="SettingController" && $action=="add" )?"active-link":""; ?> 
                <li class="{{$active}}"><a class="{{$active}}" href="{{route('settings.add')}}"><i class="fa fa-angle-right"></i>&nbsp; Add New </a></li>
            </ul>
        </li>
        </ul>
        <!-- /#menu -->
    </div>
    <!-- /#left -->