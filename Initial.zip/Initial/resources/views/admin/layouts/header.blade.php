<div id="top">
    <nav class="navbar navbar-inverse navbar-static-top">
        <div class="container-fluid">
            
            
            <!-- Brand and toggle get grouped for better mobile display -->
            <header class="navbar-header">
                
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                </button>
                <a href="{{route('admin.dashboard')}}" class="navbar-brand">
                    @if($site_settings['site_logo'] && file_exists($site_settings['site_logo']))
                    <img src="{{url($site_settings['site_logo'])}}" style="max-height: 50px; margin-left: 15px;" alt="">
                    @else
                    <img src="{{url('public/admin/assets/img/logo.png')}}" alt="">
                    @endif
                </a>
                
            </header>
            
            <div class="topnav">
                {{--  <div class="btn-group">
                    <div class="dropdown">
                        <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                        <i class="fa fa-user"></i>&nbsp;{{Auth::guard('admin')->user()->name}}
                        <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                            <li><a href="{{route('admin.profile')}}"><i class="fa fa-pencil-square-o">&nbsp;Edit Profile </i> </a></li>
                            <li><a href="{{route('admin.logout')}}"><i class="fa fa-key"></i>&nbsp;Logout</a></li>
                        </ul>
                    </div>
                </div> --}}
                <div class="btn-group">
                    <a data-placement="bottom" data-original-title="Fullscreen" data-toggle="tooltip"
                        class="btn btn-default btn-sm" id="toggleFullScreen">
                        <i class="glyphicon glyphicon-fullscreen"></i>
                    </a>
                </div>
                <div class="btn-group">
                    <a href="{{route('admin.profile')}}" data-toggle="tooltip" data-original-title="Edit Profile" data-placement="bottom" class="btn btn-primary btn-sm">
                        <i class="fa fa-user"></i>&nbsp;{{Auth::guard('admin')->user()->name}}
                    </a>
                </div>
                <div class="btn-group">
                    <a data-placement="bottom" data-original-title="Show / Hide Left" data-toggle="tooltip"
                        class="btn btn-primary btn-sm toggle-left" id="menu-toggle">
                        <i class="fa fa-bars"></i>
                    </a>
                </div>
                <div class="btn-group">
                    <a href="{{route('admin.logout')}}" data-toggle="tooltip" data-original-title="Logout" data-placement="bottom" class="btn btn-metis-1 btn-sm">
                        <i class="fa fa-power-off"></i>
                    </a>
                </div>
                
            </div>
            
            <!--<div class="collapse navbar-collapse navbar-ex1-collapse">
                
                <ul class="nav navbar-nav">
                    <li><a href="dashboard.html">Dashboard</a></li>
                    <li><a href="table.html">Tables</a></li>
                    <li class='dropdown '>
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            Form Elements <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="form-general.html">General</a></li>
                            <li><a href="form-validation.html">Validation</a></li>
                            <li><a href="form-wysiwyg.html">WYSIWYG</a></li>
                            <li><a href="form-wizard.html">Wizard &amp; File Upload</a></li>
                        </ul>
                    </li>
                </ul>
            </div>-->
        </div>
        <!-- /.container-fluid -->
    </nav>
    <!-- /.navbar -->
    <header class="head">
        <div class="search-bar">
            {{-- <form class="main-search" action="">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Live Search ...">
                    <span class="input-group-btn">
                        <button class="btn btn-primary btn-sm text-muted" type="button">
                        <i class="fa fa-search"></i>
                        </button>
                    </span>
                </div>
            </form> --}}
            <!-- /.main-search -->

            <div class="dropdown">
                <button class="btn btn-default btn-block dropdown-toggle user-dropdown" type="button" data-toggle="dropdown">
                    @if(Auth::guard('admin')->user()->profile_image && file_exists(Auth::guard('admin')->user()->profile_image))
                    <img src="{{url(Auth::guard('admin')->user()->profile_image)}}" style="max-height: 22px;" alt="">&nbsp;
                    @endif
                    {{Auth::guard('admin')->user()->name}}
                <span class="caret"></span></button>
                <ul class="dropdown-menu" style="width: 100%;">
                    <li><a href="{{route('admin.profile')}}"><i class="fa fa-user"></i>&nbsp;Edit profile</a></li>
                    <li><a href="{{route('admin.logout')}}"><i class="fa fa-key"></i>&nbsp;Logout</a></li>
                </ul>
            </div>
        </div>
        <!-- /.search-bar -->
        <div class="main-bar">
            <div class="row">
                <div class="col-md-4">
                    <h3><i class="fa fa-home"></i>&nbsp;Admin {{(isset($title))?$title:''}}</h3>
                </div>
                <div class="col-md-8">
                    @if(isset($breadcrumbs))
                    <ol class="breadcrumb" style="margin: 0px;">
                        <li class="breadcrumb-item"><a href="{{url('/')}}">Dashboard</a></li>
                        <?php if(count($breadcrumbs)>0){ ?>
                        <?php  foreach($breadcrumbs as $breadcrumb){ ?>
                        <?php if($breadcrumb['relation']=="link"){?>
                        <li class="breadcrumb-item"><a href="{{$breadcrumb['url']}}">{{$breadcrumb['name']}}</a></li>
                        <?php }else{ ?>
                        <li class="breadcrumb-item active">{{$breadcrumb['name']}}</li>
                        <?php } ?>
                        <?php } ?>
                        <?php } ?>
                    </ol>
                    @endif
                </div>
            </div>
            <!-- /.main-bar -->
        </header>
    </div>
    <!-- /.head -->