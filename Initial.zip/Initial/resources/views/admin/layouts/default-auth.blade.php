<!doctype html>
<html>

<head>
    <meta charset="UTF-8">
    <!--IE Compatibility modes-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--Mobile first-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Admin {{(isset($title))?$title:''}}</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="description" content="Free Admin Template Based On Twitter Bootstrap 3.x">
    <meta name="author" content="">
    
    <meta name="msapplication-TileColor" content="#5bc0de" />
    <meta name="msapplication-TileImage" content="{{url('public/admin/assets/img/metis-tile.png')}}" />
    
    <!-- Bootstrap -->
    <link rel="stylesheet" href="{{url('public/admin/assets/lib/bootstrap/css/bootstrap.css')}}">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="{{url('public/admin/assets/font-awesome/css/font-awesome.min.css')}}">
    
    <!-- Metis core stylesheet -->
    <link rel="stylesheet" href="{{url('public/admin/assets/css/main.css')}}">
    <link rel="stylesheet" href="{{url('public/admin/css/helper.css')}}">
    <link rel="stylesheet" href="{{url('public/admin/css/semantic.min.css')}}">
     
    <link rel="stylesheet" href="{{url('public/admin/css/custom.css')}}">
    @yield('styles')


<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
    
  </head>

        <body class="login">
            <div class="text-center m-b-20">
                 @if($site_settings['site_logo'] && file_exists($site_settings['site_logo']))
                    <img src="{{url($site_settings['site_logo'])}}" style="max-height: 75px;" alt="">
                @else
                    <img src="{{url('public/admin/assets/img/logo.png')}}" alt="">
                @endif
            </div> 
            <div style="max-width: 330px;margin:0 auto;">
                @include('admin.layouts.flash')
            </div>
            @yield('content')
            <!--jQuery -->
            <script src="{{url('public/admin/assets/lib/jquery/jquery.js')}}"></script> 
            <!--Bootstrap -->
            <script src="{{url('public/admin/assets/lib/bootstrap/js/bootstrap.js')}}"></script>
            <script src="{{url('public/admin/js/sweetalert.min.js')}}"></script>
            <script src="{{url('public/admin/js/custum.js')}}"></script>
            @yield('scripts')
        </body>

</html>
