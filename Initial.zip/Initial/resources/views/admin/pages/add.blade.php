@extends('admin.layouts.default')
@section('content')
{{Form::model($data,array('url'=>'','files'=>'true','class'=>'ui form','id'=>'template-form','autocomplete'=>'off'))}}
<div class="ui segment">
  <div class="field">
    <label>Title</label>
    {{Form::text('title',null,array('placeholder'=>'Title','id'=>'title'))}}
    <span class="error title"></span>
  </div>
  <div class="field">
    <label>Slug</label>
    {{Form::text('slug',null,array('placeholder'=>'Title','id'=>'slug','readonly'=>'readonly'))}}
    <span class="error slug"></span>
  </div>
  <div class="field">
    <label>Content</label>
    {{Form::textarea('content',null,array('placeholder'=>'Content','id'=>'content','class'=>'summernote'))}}
    <span class="error content"></span>
  </div>
  <div class="field">
    <label>Meta Title</label>
    {{Form::text('meta_title',null,array('placeholder'=>'Title','id'=>'meta_title'))}}
    <span class="error meta_title"></span>
  </div>
  <div class="field">
    <label>Meta Content</label>
    {{Form::textarea('meta_content',null,array('placeholder'=>'Content','id'=>'meta_content','rows'=>3))}}
    <span class="error meta_content"></span>
  </div>
  <button class="ui button primary" type="submit">Save</button>
  <button class="ui button" type="button" onclick="goBack()">Back</button>
</div>
{{Form::close()}}
@stop
@section('scripts')
<script>
  $(document).ready(function() {
    $('.summernote').summernote({
      height:300
    });
  });

  $("#template-form").on('submit',function(e){
    e.preventDefault();
    $(".segment").addClass('loading');
    $(".error").html("");
        $.ajax({
            url: '{!! route('pages.add',$id) !!}',
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) { 
              $(".segment").removeClass('loading');
              if(data.status==true){
                window.location.href = '{!! route('pages.index') !!}';
              }else{
                swal("Oh noez!",data.message, "error");
              }
            },
            error: function (data) {
              $(".segment").removeClass('loading');
              var response = JSON.parse(data.responseText); 
              $.each(response.errors, function (k, v) {
                  $("." + k).html(v);
              }); 
            }
        });
  })
  $("#title").keyup(function(){
      var Text = $(this).val();
      Text = convertToSlug($.trim(Text));
      $("#slug").val(Text);    
  });
  $("#title").change(function(){
      var Text = $(this).val();
      Text = convertToSlug($.trim(Text));
      $("#slug").val(Text);    
  });
</script>
@stop