@extends('admin.layouts.default')
@section('title','Dashboard')
@section('content')
<div class="row">
	<div class="col-md-4">
		<a href="{{route('users.index')}}">
			<div class="ui steps" style="width: 100%;">
				<div class="step">
					<i class="circular users icon"></i>
					<div class="content">
						<div class="title">Users ({{$users}})</div>
					</div>
				</div>
			</div>
		</a>
	</div>

	<div class="col-md-4">
		<a href="{{route('pages.index')}}">
			<div class="ui steps" style="width: 100%;">
				<div class="step">
					<i class="circular file icon"></i>
					<div class="content">
						<div class="title">CMS Pages ({{$pages}})</div>
					</div>
				</div>
			</div>
		</a>
	</div>

	<div class="col-md-4">
		<a href="{{route('templates.index')}}">
			<div class="ui steps" style="width: 100%;">
				<div class="step">
					<i class="circular envelope icon"></i>
					<div class="content">
						<div class="title">Email Templates ({{$templates}})</div>
					</div>
				</div>
			</div>
		</a>
	</div>

</div>
@stop