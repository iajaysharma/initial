@extends('admin.layouts.default')
@section('content')
 <!-- Container fluid  -->
<div class="container-fluid">
    <!-- Start Page Content -->
    <div class="row">
        <div class="col-12">
            <div class="ui segment">
                <div class="body">
                    <h4 class="title">{{$title}}</h4>
                    <div class="table-responsive m-t-40">
                        <table id="users_datatables" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Title</th>
                                    <th>Slug</th> 
                                    <th>Created</th> 
                                    <th>Actions</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End PAge Content -->
</div>
<!-- End Container fluid  -->
@stop
@section('scripts')
<script>
    function confirm_delete(id){      
        if(id!=""){
            swal({
              title: 'Are you sure?',
              text: "You won't be able to revert this!", 
              buttons: true,
            }).then((result) => {
              if (result) {
                    $(".segment").addClass("loading");
                    $.ajax({
                        url: '{{route('pages.delete')}}',
                        type: 'POST',
                        data:{user_id:id},
                        headers: {
                        'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function (response) {
                          var data = JSON.parse(response)
                          if(data.type=='success'){
                                $("#delete_"+id).parents("tr").remove();
                          }else{
                            swal(data.data);
                          }
                          $(".segment").removeClass("loading");
                        },error:function(error){
                          var data = JSON.parse(error)
                          swal(data.data);
                          $(".segment").removeClass("loading");
                        }
                    });
              }
            })
        }
    }
	$(function() {
    var table = $('#users_datatables').DataTable({
    processing: true,
    serverSide: true,
    order: [[0, "desc" ]],
    "ajax":{
    "url": '{!! route('pages.datatables') !!}',
    "dataType": "json",
    "type": "POST",
    "data":{ _token: "{{csrf_token()}}"}
    },
    columns: [ 
      { data: 'id', name: 'id', orderable:true },
      { data: 'title', name: 'title', orderable:true  },
      { data: 'slug', name: 'slug', orderable:true}, 
      { data: 'created_at', name: 'created_at', orderable:true }, 
      { data: 'action', name: 'action', orderable:false }  
    ],
    "columnDefs": [
    { "searchable": false, "targets": 0 }
    ]
    ,language: {
        searchPlaceholder: "Search by id,name or slug"
    }
    });    
  });
</script>
@stop