@extends('admin.layouts.default')
@section('content')
<!-- Start Page Content -->
<div class="row">
	<!-- Column -->
	<div class="col-lg-6">
		<div class="ui segment">
			<div class="box-two">
				<div class="avatar text-center">
					@if($profile->profile_image)
					<img alt="{{$profile->username}}" style="max-height: 150px;" src="{{url($profile->profile_image)}}">
					@endif
				</div>
				<h3 class="text-center">{{$profile->name}}</h3>
				<div style="text-align: center" class="card-body">
					<div class="row">
						<div class="col-md-6 col-xs-6 b-r"> <strong>Name</strong>
							<br>
							<p class="text-muted">{{$profile->name}}</p>
						</div>
						<div class="col-md-6 col-xs-6"> <strong>Location</strong>
							<br>
							<p class="text-muted">{{$profile->country->name}}</p>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6 col-xs-6 b-r"> <strong>Email</strong>
							<br>
							<p class="text-muted">{{$profile->email}}</p>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		<div class="ui segments">
			<div class="ui segment">
				<p>Change Password</p>
			</div>
			<div class="ui secondary segment">
				<form class="ui form" id="change-password">
					{{csrf_field()}}
					<div class="field">
						<label>Current Password</label>
						<input type="password" class="blank" name="current_password" placeholder="Current Password">
						<span class="error current_password"></span>
					</div>
					<div class="field">
						<label>New Password</label>
						<input type="password" class="blank" name="new_password" placeholder="New Password">
						<span class="error new_password"></span>
					</div> 
					<button class="ui button primary btn-block" type="submit">Submit</button>
				</form>
			</div>
		</div>
	</div>
	<!-- Column -->
	<!-- Column -->
	<div class="col-lg-6">
		<div class="box dark">
			<div class="body">
				{{Form::model($profile,array('files'=>true,'class'=>'form-horizontal ui form'))}}
				<div class="form-group">
					<label class="col-md-12">Profile Image</label>
					<div class="row">
						<div class="col-md-7 ">
							<div class="form-control" style="margin-left:12px;">
								<input name="profile_image" id="profile_image" class="" type="file">
							</div>
							<span class="text-danger">{{$errors->first('profile_image')}}</span>
						</div>
						@if($profile->profile_image)
						<div class="col-md-4">
							<img class="img-responsive img-thumbnail" alt="{{$profile->username}}" src="{{url($profile->profile_image)}}">
						</div>
						@endif
					</div>
				</div>
				
				<div class="form-group">
					<label class="col-md-12">Name</label>
					<div class="col-md-12">
						{{Form::text('name',null,array('class'=>'','placeholder'=>'Name'))}}
						<span class="text-danger">{{$errors->first('name')}}</span>
					</div>
				</div>
				<div class="form-group">
					<label for="example-email" class="col-md-12">Email</label>
					<div class="col-md-12">
						{{Form::email('email',null,array('class'=>'','placeholder'=>'Email'))}}
						<span class="text-danger">{{$errors->first('email')}}</span>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-12">Select Country</label>
					<div class="col-sm-12">
						{{Form::select('country_id',$countries,null,array('class'=>''))}}
						<span class="text-danger">{{$errors->first('country_id')}}</span>
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-12">
						<button class="ui button primary btn-block">Update Profile</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
</div>
@stop
@section('scripts')
<script>
	$("#change-password").on('submit',function(e){
		e.preventDefault();
	    $(".secondary").addClass('loading');
	    $(".error").html("");
	    $.ajax({
	        url: baseUrl+'/admin/update-password',
	        type: "POST",
	        data: new FormData(this),
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (data) { 
	            $(".segment").removeClass('loading');
	            if(data.status==true){                  
	            	$(".blank").val('');
	                swal("Ohh!!Yes",data.message,"success");
	            }else{
	                swal("Ohh!!No",data.message,"error");
	            }
	        },
	        error: function (data) {
	            $(".segment").removeClass('loading');
	            var response = JSON.parse(data.responseText); 
	            $.each(response.errors, function (k, v) {
	                $("." + k).html(v);
	            }); 
	        }
	    });    
	});
</script>	
@stop