@extends('admin.layouts.default')
@section('content')
<div class="container-fluid">
  {{Form::model($data,array('url'=>url('admin/category/add/'.$id),'files'=>'true'))}}
  <div class="row">
    <div class="col-6">
      <div class="card">
        <div class="card-body">
          <div class="form-group {{ $errors->has('name') ? 'has-error' : '' }}">
            <label for="name">Name<span class="text-danger">*</span></label>
            {{Form::text('name',null,array('class'=>'form-control','placeholder'=>'Name','id'=>'name'))}}
            <span class="{{ $errors->has('name') ? 'ti-alert text-danger text-danger' : '' }}">{{$errors->first('name')}}</span>
          </div>
          <div class="form-group {{ $errors->has('slug') ? 'has-error' : '' }}">
            <label for="slug">Slug<span class="text-danger">*</span></label>
            {{Form::text('slug',null,array('class'=>'form-control','placeholder'=>'Slug','id'=>'slug'))}}
            <span class="{{ $errors->has('slug') ? 'ti-alert text-danger text-danger' : '' }}">{{$errors->first('slug')}}</span>
          </div>
          <div class="form-group {{ $errors->has('status') ? 'has-error' : '' }}">
            <label for="status">Status<span class="text-danger">*</span></label>
            {{Form::select('status',config('constants.CATEGORY_STATUS'),null,array("class"=>"form-control custom-select"))}}
            <span class="{{ $errors->has('status') ? 'ti-alert text-danger' : '' }}">{{$errors->first('status')}}</span>
          </div>
          <div class="form-group {{ $errors->has('description') ? 'has-error' : '' }}">
            <label for="description">Description<span class="text-danger"></span></label>
            {{Form::textarea('description',null,array("class"=>"",'rows'=>3,'style'=>'width:100%;padding:10px;','maxlength'=>300))}}
            <span class="text-info">Max 300 characters allowed.</span>
            <span class="{{ $errors->has('description') ? 'ti-alert text-danger' : '' }}">{{$errors->first('description')}}</span>
          </div>
          <div for="image">Photo</div>
          <div class="input-group image-preview {{ $errors->has('photo') ? 'has-error' : '' }}">
            <input type="text" class="form-control image-preview-filename" disabled="disabled">
            <span class="input-group-btn">
              <button type="button" class="btn btn-danger image-preview-clear" style="display:none;">Clear</button>
              <div class="btn btn-secondary image-preview-input">
                <span class="image-preview-input-title">Browse</span>
                <input type="file" accept="image/png, image/jpeg, image/gif, image/jpg" name="photo"/>
              </div>
            </span>
          </div>
          <div class="form-group {{ $errors->has('photo') ? 'ti-alert text-danger' : '' }}">{{$errors->first('photo')}}</div>
          <div class="form-group">
            @if(isset($data->photo) && $data->photo!="" && file_exists(public_path().'/upload/category/thumbnail_images/'.$data->photo))
            <img src="{{url('public/upload/category/thumbnail_images/'.$data->photo)}}" class="img-thumbnail" alt="">
            @endif
          </div>
          <div class="form-group">
            <div class="btn-group">
              <button type="submit" class="btn btn-success">Save</button>&nbsp;
              <a href="{{route('category.index')}}" class="btn btn-secondary">Cancel</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  {{Form::close()}}
</div>
@stop
@section('scripts')
<script>
  $("#name").bind("change keyup", function(){
      var string = this.value;
      converted = convertToSlug(string);
      $("#slug").val(converted);
  });
  $("#slug").bind("change keyup", function(){
      var string = this.value;
      converted = convertToSlug(string);
      $("#slug").val(converted);
  });
  function convertToSlug(Text)
  {
      return Text
          .toLowerCase()
          .replace(/ /g,'-')
          .replace(/[^\w-]+/g,'')
          ;
  }
</script>
@stop