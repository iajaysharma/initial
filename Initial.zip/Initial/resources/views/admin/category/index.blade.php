@extends('admin.layouts.default')
@section('content')
 <!-- Container fluid  -->
<div class="container-fluid">
    <!-- Start Page Content -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">{{isset($title)?$title:''}}<a href="{{route('category.add')}}" class="btn btn-info pull-right">Add New Category</a></h4>

                    <div class="table-responsive m-t-40">
                        <table id="users_datatables" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Slug</th> 
                                    <th>Description</th> 
                                    <th>Photo</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End PAge Content -->
</div>
<!-- End Container fluid  -->
@stop
@section('scripts')
<script>
    function confirm_delete(id){
        if(id!=""){
            swal({
              title: 'Are you sure?',
              text: "You won't be able to revert this!",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
              if (result.value) {
                    $.ajax({
                        url: '{{route('category.delete')}}',
                        type: 'POST',
                        data:{id:id},
                        headers: {
                        'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function (response) {
                          var data = JSON.parse(response)
                          if(data.type=='success'){
                                $("#delete_"+id).parents("tr").remove();
                          }else{
                            swal(data.data);
                          }
                        }
                    });
              }
            })
        }
    }
	function changeStatus(id)
	{
	    $.ajax({
	        url: '{{route('category.status')}}',
	        type: 'POST',
	        data:{id:id},
	        headers: {
	        'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
	        },
	        success: function (response) {
	          $("#status_"+id).html(response);
	        }
	    });
	}
	$(function() {
    var table = $('#users_datatables').DataTable({
    processing: true,
    serverSide: true,
    order: [[0, "desc" ]],
    "ajax":{
    "url": '{!! route('category.datatables') !!}',
    "dataType": "json",
    "type": "POST",
    "data":{ _token: "{{csrf_token()}}"}
    },
    columns: [ 
      { data: 'id', name: 'id', orderable:true },
      { data: 'name', name: 'name', orderable:true  },
      { data: 'slug', name: 'slug', orderable:true}, 
      { data: 'description', name: 'description', orderable:false,width:'30%'}, 
      { data: 'photo', name: 'photo', orderable:false },
      { data: 'status', name: 'status', orderable:false},
      { data: 'action', name: 'action', orderable:false }  
    ],
    "columnDefs": [
    { "searchable": false, "targets": 0 }
    ]
    ,language: {
        searchPlaceholder: "Search by id,name or slug"
    }
    });    
  });
</script>
@stop