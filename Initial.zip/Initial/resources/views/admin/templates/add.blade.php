@extends('admin.layouts.default')
@section('content')
{{Form::model($data,array('url'=>'','files'=>'true','class'=>'ui form','id'=>'template-form','autocomplete'=>'off'))}}
<div class="ui segment">
  <div class="field">
    <label>Title</label>
    {{Form::text('title',null,array('placeholder'=>'Title','id'=>'title'))}}
    <span class="error title"></span>
  </div>
  <div class="field">
    <label>Slug</label>
    {{Form::text('slug',null,array('placeholder'=>'Title','id'=>'slug','readonly'=>'readonly'))}}
    <span class="error slug"></span>
  </div>
  <div class="field">
    <label>Keys</label>
    {{Form::text('keys',null,array('placeholder'=>'Keys','id'=>'keys'))}}
    <span class="error keys"></span>
  </div>
  <div class="field">
    <label>Content</label>
    {{Form::textarea('content',null,array('placeholder'=>'Content','id'=>'content','class'=>'summernote'))}}
    <span class="error content"></span>
  </div>
  <button class="ui button primary" type="submit">Save</button>
  <button class="ui button" type="button" onclick="goBack()">Back</button>
</div>
{{Form::close()}}
@stop
@section('scripts')
<script>
  $(document).ready(function() {
    $('.summernote').summernote({
      height:300
    });
  });

  $("#template-form").on('submit',function(e){
    e.preventDefault();
    $(".segment").addClass('loading');
    $(".error").html("");
        $.ajax({
            url: '{!! route('templates.add',$id) !!}',
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) { 
              $(".segment").removeClass('loading');
              if(data.status==true){
                window.location.href = '{!! route('templates.index') !!}';
              }else{
                swal("Oh noez!",data.message, "error");
              }
            },
            error: function (data) {
              $(".segment").removeClass('loading');
              var response = JSON.parse(data.responseText); 
              $.each(response.errors, function (k, v) {
                  $("." + k).html(v);
              }); 
            }
        });
  })
</script>
@if(!$id)
<script>
  $("#title").keyup(function(){
      var Text = $(this).val();
      Text = convertToSlug($.trim(Text));
      $("#slug").val(Text);    
  });
  $("#title").change(function(){
      var Text = $(this).val();
      Text = convertToSlug($.trim(Text));
      $("#slug").val(Text);    
  });
</script>
@endif
@stop