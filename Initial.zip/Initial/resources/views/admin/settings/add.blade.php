@extends('admin.layouts.default')
@section('content')
{{Form::model($data,array('url'=>'','files'=>'true','class'=>'ui form','id'=>'setting-form','autocomplete'=>'off'))}}
<div class="ui segment">
  <div class="field">
    <label>Field Title</label>
    {{Form::text('field_title',null,array('placeholder'=>'Field Title','id'=>'field_title'))}}
    <span class="error field_title"></span>
  </div>
  <div class="field">
    <label>Field Name</label>
    {{Form::text('field_name',null,array('placeholder'=>'Field Name','id'=>'field_name','readonly'=>'readonly'))}}
    <span class="error field_name"></span>
  </div>
  <div class="field">
    <label>Field Type</label>
    {{Form::select('field_type',array('text'=>'Text','image'=>'Image','email'=>'Email','number'=>'Number','url'=>'Url','date'=>'Date'),null,array('placeholder'=>'Select Field Type','id'=>'field_type'))}}
    <span class="error field_type"></span>
  </div>
  <div class="field new-field">
    @if($id)
      @if($data->field_type=='image')
          <label>Field Value</label>
          {!!Form::file('value',array('id'=>'value'))!!}
          <img src="{{url($data->value)}}" style="max-height: 75px;" alt=""><br>
          <span class="error value"></span>
      @else
          <label>Field Value</label>
          {!!Form::text('value',null,array('placeholder'=>'Value','id'=>'value'))!!}
          <span class="error value"></span>
      @endif
    @endif
  </div> 
  <button class="ui button primary" type="submit">Save</button>
  <button onClick="goBack()" class="ui button" type="button">Back</button>
</div>
{{Form::close()}}
@stop
@section('scripts')
<script>
  $("#setting-form").on('submit',function(e){
    e.preventDefault();
    $(".segment").addClass('loading');
    $(".error").html("");
        $.ajax({
            url: '{!! route('settings.add',$id) !!}',
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) { 
              $(".segment").removeClass('loading');
              if(data.status==true){
                window.location.href = '{!! route('settings.index') !!}';
              }else{
                swal("Oh noez!",data.message, "error");
              }
            },
            error: function (data) {
              $(".segment").removeClass('loading');
              var response = JSON.parse(data.responseText); 
              $.each(response.errors, function (k, v) {
                  $("." + k).html(v);
              }); 
            }
        });
  });

  $("#field_title").keyup(function(){
      var Text = $(this).val();
      Text = convertToName($.trim(Text));
      $("#field_name").val(Text);    
  });
  $("#field_title").change(function(){
      var Text = $(this).val();
      Text = convertToName($.trim(Text));
      $("#field_name").val(Text);    
  });

  $("#field_type").on('change',function(e){
      var type = e.target.value;
      if(type=="image"){
        var append = '<label>Field Value</label>{!!Form::file('value',array('id'=>'value'))!!}<span class="error value"></span>';                
      }else{
        var append = '<label>Field Value</label><input type='+type+' name="value" placeholder="value"><span class="error value"></span>';
      }
      $(".new-field").html(append);
  });
</script>
@stop