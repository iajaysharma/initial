@extends('admin.layouts.default-auth')
@section('content')
<div class="form-signin ">
    <div class="ui center aligned segment">
        Verification
    </div>
</div>
@stop