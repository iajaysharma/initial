var host = location.host;
if(host=="localhost" || host=="192.168.0.181"){
	baseUrl = location.protocol + '//' + location.host+'/Initial';
}else{
	baseUrl = location.protocol + '//' + location.host
}

$("#loginForm").on('submit', (function (e) {
        e.preventDefault();
        $(".segment").addClass('loading');
        $(".alert-box").hide();
        $(".error").html("");
        $.ajax({
            url: baseUrl+'/admin',
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) { 
                $(".segment").removeClass('loading');
                if(data.status==true){
                    window.location.href = baseUrl+'/admin/dashboard';
                }else{
                    $(".alert-box").html(data.message);
                    $(".alert-box").show();
                }
            },
            error: function (data) {
                $(".segment").removeClass('loading');
                var response = JSON.parse(data.responseText); 
                $.each(response.errors, function (k, v) {
                    $("." + k).html(v);
                }); 
            }
        });        

    }));

$("#admin-reset-form").on('submit', (function (e) {
    e.preventDefault();
    $(".segment").addClass('loading');
    $(".error").html("");
    $.ajax({
        url: baseUrl+'/admin/reset-password',
        type: "POST",
        data: new FormData(this),
        contentType: false,
        cache: false,
        processData: false,
        success: function (data) { 
            $(".segment").removeClass('loading');
            if(data.status==true){                  
                swal("Ohh!!Yes",data.message,"success");
            }else{
                swal("Ohh!!No",data.message,"error");
            }
        },
        error: function (data) {
            $(".segment").removeClass('loading');
            var response = JSON.parse(data.responseText); 
            $.each(response.errors, function (k, v) {
                $("." + k).html(v);
            }); 
        }
    });        

}));

function convertToSlug(Text)
{
    return Text
        .toLowerCase()
        .replace(/ /g,'-')
        .replace(/[^\w-]+/g,'')
        ;
}

function convertToName(Text)
{
    return Text
        .toLowerCase()
        .replace(/ /g,'_')
        .replace(/[^\w-]+/g,'')
        ;
}

function goBack() {
    window.history.back();
}